package myau.ui;

import myau.Myau;
import myau.module.Module;
import myau.module.modules.*;
import myau.property.Property;
import myau.property.properties.*;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ChatAllowedCharacters;
import myau.util.KeyBindUtil;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.io.IOException;
import java.util.*;

/**
 * Vape-style click GUI: dark window, category sidebar on the left,
 * module list on the right. Left click = toggle, right click = expand settings.
 * Everything is drawn with plain rects/text (no external assets).
 */
public class VapeGui extends GuiScreen {
    // ---- look & feel
    private static final int ACCENT = new Color(38, 198, 160).getRGB();
    private static final int BG_WINDOW = new Color(24, 24, 28, 245).getRGB();
    private static final int BG_SIDE = new Color(18, 18, 21, 250).getRGB();
    private static final int BG_ROW = new Color(32, 32, 37).getRGB();
    private static final int BG_ROW_HOVER = new Color(40, 40, 46).getRGB();
    private static final int BG_SETTING = new Color(27, 27, 31).getRGB();
    private static final int TEXT = new Color(225, 225, 230).getRGB();
    private static final int TEXT_DIM = new Color(140, 140, 150).getRGB();
    private static final int TRACK = new Color(55, 55, 62).getRGB();

    private static final int SIDE_W = 92;
    private static final int ROW_MOD = 22;
    private static final int ROW_BOOL = 18;
    private static final int ROW_SLIDER = 26;
    private static final int ROW_MODE = 18;
    private static final int ROW_BIND = 18;
    private static final int ROW_COLOR = 44;
    private static final int SEARCH_W = 110;

    private static VapeGui instance;

    private final LinkedHashMap<String, List<Module>> categories = new LinkedHashMap<>();
    private final Set<Module> expanded = new HashSet<>();
    private final Map<Module, Float> toggleAnim = new HashMap<>();
    private final Map<Property<?>, Float> boolAnim = new HashMap<>();
    private String selected;
    private float scroll = 0f;
    private float scrollTarget = 0f;
    private int contentHeight = 0;

    // search + bind state
    private String search = "";
    private boolean searchFocused = false;
    private Module bindingModule = null;

    // slider drag state
    private Property<?> dragging = null;
    private int dragX, dragW;
    private int dragChannel = 0;

    // window geometry (recomputed every frame)
    private int wx, wy, ww, wh;
    private int listX, listY, listW, listH;

    private static class Row {
        int type; // 0 = module, 1 = boolean, 2 = slider, 3 = mode, 4 = bind, 5 = color
        Module module;
        Property<?> prop;
        int y;
        int h;
    }

    public VapeGui() {
        instance = this;
        add("Combat", AimAssist.class, AutoClicker.class, KillAura.class, Wtap.class, Velocity.class, Freeze.class,
                Reach.class, TargetStrafe.class, NoHitDelay.class, AntiFireball.class, LagRange.class, HitBox.class,
                MoreKB.class, Refill.class, HitSelect.class, SilentAura.class, HitFlick.class, BackTrack.class);
        add("Movement", AntiAFK.class, Fly.class, Speed.class, LongJump.class, Sprint.class, SafeWalk.class,
                Jesus.class, Blink.class, NoFall.class, NoSlow.class, KeepSprint.class, Eagle.class,
                NoJumpDelay.class, AntiVoid.class);
        add("Render", ESP.class, Chams.class, FullBright.class, Tracers.class, NameTags.class, Xray.class,
                TargetHUD.class, Indicators.class, BedESP.class, ItemESP.class, ViewClip.class, NoHurtCam.class,
                HUD.class, GuiModule.class, ChestESP.class, Trajectories.class, Radar.class);
        add("Player", AutoHeal.class, AutoTool.class, ChestStealer.class, InvManager.class, InvWalk.class,
                Scaffold.class, AutoBlockIn.class, SpeedMine.class, FastPlace.class, GhostHand.class, MCF.class,
                AntiDebuff.class);
        add("Misc", Spammer.class, BedNuker.class, BedTracker.class, LightningTracker.class, NoRotate.class,
                NickHider.class, AntiObbyTrap.class, AntiObfuscate.class, AutoAnduril.class, InventoryClicker.class);
        add("Legit Mods", FreeLook.class, Keystrokes.class, HitColor.class, BlockOverlay.class);
        this.selected = this.categories.keySet().iterator().next();
    }

    public static VapeGui getInstance() {
        return instance;
    }

    private void add(String name, Class<?>... classes) {
        List<Module> list = new ArrayList<>();
        for (Class<?> c : classes) {
            Module m = Myau.moduleManager.getModule(c);
            if (m != null) list.add(m);
        }
        list.sort(Comparator.comparing(m -> m.getName().toLowerCase()));
        this.categories.put(name, list);
    }

    // ------------------------------------------------------------------ layout

    private void computeGeometry() {
        this.ww = Math.min(400, this.width - 20);
        this.wh = Math.min(260, this.height - 20);
        this.wx = (this.width - this.ww) / 2;
        this.wy = (this.height - this.wh) / 2;
        this.listX = this.wx + SIDE_W + 8;
        this.listY = this.wy + 30;
        this.listW = this.ww - SIDE_W - 16;
        this.listH = this.wh - 38;
    }

    private List<Module> currentModules() {
        if (this.search.isEmpty()) {
            return this.categories.get(this.selected);
        }
        String q = this.search.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (List<Module> list : this.categories.values()) {
            for (Module m : list) {
                if (m.getName().toLowerCase().contains(q)) out.add(m);
            }
        }
        out.sort(Comparator.comparing(m -> m.getName().toLowerCase()));
        return out;
    }

    private String bindText(Module m) {
        if (this.bindingModule == m) return "Press a key...";
        return m.getKey() == 0 ? "None" : KeyBindUtil.getKeyName(m.getKey());
    }

    private List<Property<?>> settingsOf(Module module) {
        List<Property<?>> out = new ArrayList<>();
        ArrayList<Property<?>> all = Myau.propertyManager.properties.get(module.getClass());
        if (all == null) return out;
        for (Property<?> p : all) {
            if (!p.isVisible()) continue;
            if (p instanceof BooleanProperty || p instanceof FloatProperty || p instanceof IntProperty
                    || p instanceof PercentProperty || p instanceof ModeProperty || p instanceof ColorProperty) {
                out.add(p);
            }
        }
        return out;
    }

    private List<Row> buildRows() {
        List<Row> rows = new ArrayList<>();
        int y = 0;
        for (Module m : currentModules()) {
            Row r = new Row();
            r.type = 0;
            r.module = m;
            r.y = y;
            r.h = ROW_MOD;
            rows.add(r);
            y += ROW_MOD + 2;
            if (this.expanded.contains(m)) {
                Row b = new Row();
                b.type = 4;
                b.module = m;
                b.h = ROW_BIND;
                b.y = y;
                rows.add(b);
                y += ROW_BIND;
                for (Property<?> p : settingsOf(m)) {
                    Row s = new Row();
                    s.module = m;
                    s.prop = p;
                    if (p instanceof BooleanProperty) {
                        s.type = 1;
                        s.h = ROW_BOOL;
                    } else if (p instanceof ModeProperty) {
                        s.type = 3;
                        s.h = ROW_MODE;
                    } else if (p instanceof ColorProperty) {
                        s.type = 5;
                        s.h = ROW_COLOR;
                    } else {
                        s.type = 2;
                        s.h = ROW_SLIDER;
                    }
                    s.y = y;
                    rows.add(s);
                    y += s.h;
                }
                y += 4;
            }
        }
        this.contentHeight = y;
        return rows;
    }

    // ------------------------------------------------------------------ drawing helpers

    private static void roundRect(int x1, int y1, int x2, int y2, int r, int color) {
        if (r <= 0) {
            drawRect(x1, y1, x2, y2, color);
            return;
        }
        drawRect(x1 + r, y1, x2 - r, y2, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
            drawRect(x1 + inset, y1 + i, x1 + r, y1 + i + 1, color);
            drawRect(x2 - r, y1 + i, x2 - inset, y1 + i + 1, color);
            drawRect(x1 + inset, y2 - i - 1, x1 + r, y2 - i, color);
            drawRect(x2 - r, y2 - i - 1, x2 - inset, y2 - i, color);
        }
        drawRect(x1, y1 + r, x1 + r, y2 - r, color);
        drawRect(x2 - r, y1 + r, x2, y2 - r, color);
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return new Color((int) (ar + (br - ar) * t), (int) (ag + (bg - ag) * t), (int) (ab + (bb - ab) * t)).getRGB();
    }

    private void scissor(int x, int y, int w, int h) {
        int f = new ScaledResolution(this.mc).getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(x * f, (this.height - (y + h)) * f, w * f, h * f);
    }

    private static String pretty(String name) {
        String s = name.replace("-", " ");
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private String valueText(Property<?> p) {
        if (p instanceof FloatProperty) {
            return String.format(Locale.US, "%.2f", ((FloatProperty) p).getValue());
        }
        if (p instanceof PercentProperty) {
            return ((PercentProperty) p).getValue() + "%";
        }
        return String.valueOf(p.getValue());
    }

    private void setColorChannel(ColorProperty p, int channel, float pct) {
        int c = p.getValue() & 0xFFFFFF;
        int v = Math.round(Math.max(0f, Math.min(1f, pct)) * 255f);
        int shift = 16 - channel * 8;
        c = (c & ~(0xFF << shift)) | (v << shift);
        p.setValue(c);
    }

    private float sliderPct(Property<?> p) {
        double v, min, max;
        if (p instanceof FloatProperty) {
            v = ((FloatProperty) p).getValue();
            min = ((FloatProperty) p).getMinimum();
            max = ((FloatProperty) p).getMaximum();
        } else if (p instanceof IntProperty) {
            v = ((IntProperty) p).getValue();
            min = ((IntProperty) p).getMinimum();
            max = ((IntProperty) p).getMaximum();
        } else {
            v = ((PercentProperty) p).getValue();
            min = ((PercentProperty) p).getMinimum();
            max = ((PercentProperty) p).getMaximum();
        }
        return max <= min ? 0f : (float) ((v - min) / (max - min));
    }

    private void setSliderPct(Property<?> p, float pct) {
        pct = Math.max(0f, Math.min(1f, pct));
        if (p instanceof FloatProperty) {
            FloatProperty f = (FloatProperty) p;
            float v = f.getMinimum() + (f.getMaximum() - f.getMinimum()) * pct;
            f.setValue(Math.round(v * 20f) / 20f); // step 0.05
        } else if (p instanceof IntProperty) {
            IntProperty i = (IntProperty) p;
            i.setValue(Math.round(i.getMinimum() + (i.getMaximum() - i.getMinimum()) * pct));
        } else if (p instanceof PercentProperty) {
            PercentProperty i = (PercentProperty) p;
            i.setValue(Math.round(i.getMinimum() + (i.getMaximum() - i.getMinimum()) * pct));
        }
    }

    // ------------------------------------------------------------------ screen

    @Override
    public void drawScreen(int mx, int my, float partialTicks) {
        computeGeometry();
        drawRect(0, 0, this.width, this.height, new Color(0, 0, 0, 110).getRGB());

        // window + sidebar
        roundRect(wx, wy, wx + ww, wy + wh, 5, BG_WINDOW);
        roundRect(wx, wy, wx + SIDE_W, wy + wh, 5, BG_SIDE);
        drawRect(wx + SIDE_W - 5, wy, wx + SIDE_W, wy + wh, BG_SIDE);

        this.fontRendererObj.drawStringWithShadow("MYAU", wx + 12, wy + 11, ACCENT);
        this.fontRendererObj.drawString(String.valueOf(Myau.version), wx + 12 + this.fontRendererObj.getStringWidth("MYAU") + 4, wy + 11, TEXT_DIM);

        int cy = wy + 34;
        for (String cat : this.categories.keySet()) {
            boolean sel = cat.equals(this.selected);
            boolean hov = inside(mx, my, wx, cy, SIDE_W, 24);
            if (sel) {
                drawRect(wx, cy, wx + SIDE_W, cy + 24, new Color(255, 255, 255, 14).getRGB());
                drawRect(wx, cy + 4, wx + 2, cy + 20, ACCENT);
            } else if (hov) {
                drawRect(wx, cy, wx + SIDE_W, cy + 24, new Color(255, 255, 255, 7).getRGB());
            }
            this.fontRendererObj.drawStringWithShadow(cat, wx + 14, cy + 8, sel ? TEXT : TEXT_DIM);
            cy += 24;
        }

        // header
        String title = this.search.isEmpty() ? this.selected : "Search";
        this.fontRendererObj.drawStringWithShadow(title, listX, wy + 12, TEXT);
        int sx = listX + listW - SEARCH_W - 8, sy = wy + 7;
        roundRect(sx, sy, sx + SEARCH_W, sy + 14, 3, this.searchFocused ? BG_ROW_HOVER : BG_ROW);
        if (this.searchFocused) drawRect(sx + 2, sy + 13, sx + SEARCH_W - 2, sy + 14, ACCENT);
        String shown = this.search.isEmpty() && !this.searchFocused ? "Search..." : this.search;
        while (this.fontRendererObj.getStringWidth(shown) > SEARCH_W - 14 && shown.length() > 1) shown = shown.substring(1);
        boolean caret = this.searchFocused && (System.currentTimeMillis() / 500) % 2 == 0;
        this.fontRendererObj.drawString(shown + (caret ? "_" : ""), sx + 5, sy + 3, this.search.isEmpty() && !this.searchFocused ? TEXT_DIM : TEXT);
        drawRect(listX, wy + 25, listX + listW, wy + 26, new Color(255, 255, 255, 16).getRGB());

        // slider dragging
        if (this.dragging != null) {
            if (Mouse.isButtonDown(0)) {
                float pct = (mx - dragX) / (float) dragW;
                if (this.dragging instanceof ColorProperty) {
                    setColorChannel((ColorProperty) this.dragging, this.dragChannel, pct);
                } else {
                    setSliderPct(this.dragging, pct);
                }
            } else {
                this.dragging = null;
            }
        }

        // smooth scroll
        int maxScroll = Math.max(0, this.contentHeight - this.listH);
        this.scrollTarget = Math.max(0, Math.min(maxScroll, this.scrollTarget));
        this.scroll += (this.scrollTarget - this.scroll) * 0.3f;

        List<Row> rows = buildRows();
        scissor(listX, listY, listW, listH);
        for (Row r : rows) {
            int ry = listY + r.y - (int) this.scroll;
            if (ry + r.h < listY || ry > listY + listH) continue;
            drawRow(r, ry, mx, my);
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        // scrollbar
        if (this.contentHeight > this.listH) {
            float ratio = this.listH / (float) this.contentHeight;
            int barH = Math.max(14, (int) (this.listH * ratio));
            int barY = listY + (int) ((this.listH - barH) * (this.scroll / Math.max(1, this.contentHeight - this.listH)));
            roundRect(wx + ww - 6, barY, wx + ww - 3, barY + barH, 1, new Color(255, 255, 255, 40).getRGB());
        }
    }

    private void drawRow(Row r, int ry, int mx, int my) {
        int x = listX, w = listW - 8;
        boolean hov = inside(mx, my, x, ry, w, r.h) && inside(mx, my, listX, listY, listW, listH);
        switch (r.type) {
            case 0: { // module
                Module m = r.module;
                float a = this.toggleAnim.getOrDefault(m, m.isEnabled() ? 1f : 0f);
                a += ((m.isEnabled() ? 1f : 0f) - a) * 0.25f;
                this.toggleAnim.put(m, a);
                int base = hov ? BG_ROW_HOVER : BG_ROW;
                roundRect(x, ry, x + w, ry + r.h, 3, lerpColor(base, ACCENT, a * 0.9f));
                int textColor = lerpColor(TEXT, new Color(15, 15, 18).getRGB(), a);
                int dark = new Color(12, 12, 15).getRGB();
                if (a > 0.5f) {
                    this.fontRendererObj.drawString(m.getName(), x + 8, ry + 7, dark);
                } else {
                    this.fontRendererObj.drawStringWithShadow(m.getName(), x + 8, ry + 7, textColor);
                }
                String arrow = this.expanded.contains(m) ? "v" : ">";
                this.fontRendererObj.drawString(arrow, x + w - 12, ry + 7, a > 0.5f ? dark : TEXT_DIM);
                break;
            }
            case 1: { // boolean
                BooleanProperty p = (BooleanProperty) r.prop;
                drawRect(x + 4, ry, x + w, ry + r.h, BG_SETTING);
                this.fontRendererObj.drawString(pretty(p.getName()), x + 12, ry + 5, TEXT);
                float a = this.boolAnim.getOrDefault(p, p.getValue() ? 1f : 0f);
                a += ((p.getValue() ? 1f : 0f) - a) * 0.3f;
                this.boolAnim.put(p, a);
                int sx = x + w - 26, sy = ry + 4;
                roundRect(sx, sy, sx + 18, sy + 10, 5, lerpColor(TRACK, ACCENT, a));
                int kx = sx + 1 + Math.round(a * 8);
                roundRect(kx, sy + 1, kx + 8, sy + 9, 4, TEXT);
                break;
            }
            case 2: { // slider
                Property<?> p = r.prop;
                drawRect(x + 4, ry, x + w, ry + r.h, BG_SETTING);
                this.fontRendererObj.drawString(pretty(p.getName()), x + 12, ry + 4, TEXT);
                String v = valueText(p);
                this.fontRendererObj.drawString(v, x + w - 8 - this.fontRendererObj.getStringWidth(v), ry + 4, TEXT_DIM);
                int bx = x + 12, bw = w - 24, by = ry + 17;
                roundRect(bx, by, bx + bw, by + 3, 1, TRACK);
                int fill = Math.round(bw * sliderPct(p));
                if (fill > 0) roundRect(bx, by, bx + fill, by + 3, 1, ACCENT);
                roundRect(bx + fill - 2, by - 2, bx + fill + 2, by + 5, 2, TEXT);
                break;
            }
            case 4: { // bind
                Module m = r.module;
                drawRect(x + 4, ry, x + w, ry + r.h, BG_SETTING);
                this.fontRendererObj.drawString("Bind", x + 12, ry + 5, TEXT);
                String v = bindText(m);
                int col = this.bindingModule == m ? ACCENT : TEXT_DIM;
                int bw = this.fontRendererObj.getStringWidth(v) + 10;
                roundRect(x + w - 8 - bw, ry + 2, x + w - 8, ry + r.h - 2, 3, BG_ROW);
                this.fontRendererObj.drawString(v, x + w - 8 - bw + 5, ry + 5, col);
                break;
            }
            case 5: { // color
                ColorProperty p = (ColorProperty) r.prop;
                int rgb = p.getValue() & 0xFFFFFF;
                drawRect(x + 4, ry, x + w, ry + r.h, BG_SETTING);
                this.fontRendererObj.drawString(pretty(p.getName()), x + 12, ry + 4, TEXT);
                roundRect(x + w - 30, ry + 3, x + w - 8, ry + 12, 2, 0xFF000000 | rgb);
                int bx = x + 12, bw = w - 24;
                int[] tint = {0xFFE05555, 0xFF55C878, 0xFF5588E8};
                for (int i = 0; i < 3; i++) {
                    int by = ry + 16 + i * 9;
                    int val = (rgb >> (16 - i * 8)) & 0xFF;
                    roundRect(bx, by, bx + bw, by + 4, 2, TRACK);
                    int fill = Math.round(bw * (val / 255f));
                    if (fill > 0) roundRect(bx, by, bx + fill, by + 4, 2, tint[i]);
                    roundRect(bx + fill - 2, by - 1, bx + fill + 2, by + 5, 2, TEXT);
                }
                break;
            }
            case 3: { // mode
                ModeProperty p = (ModeProperty) r.prop;
                drawRect(x + 4, ry, x + w, ry + r.h, BG_SETTING);
                this.fontRendererObj.drawString(pretty(p.getName()), x + 12, ry + 5, TEXT);
                String v = "< " + p.getModeString().replace("_", " ") + " >";
                this.fontRendererObj.drawString(v, x + w - 8 - this.fontRendererObj.getStringWidth(v), ry + 5, ACCENT);
                break;
            }
            default:
                break;
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        computeGeometry();
        // search box
        int sbx = listX + listW - SEARCH_W - 8, sby = wy + 7;
        if (inside(mx, my, sbx, sby, SEARCH_W, 14) && button == 0) {
            this.searchFocused = true;
            this.bindingModule = null;
            return;
        }
        this.searchFocused = false;
        // mouse button bind (middle / side buttons)
        if (this.bindingModule != null && button >= 2) {
            this.bindingModule.setKey(button - 100);
            this.bindingModule = null;
            return;
        }
        // sidebar
        int cy = wy + 34;
        for (String cat : this.categories.keySet()) {
            if (inside(mx, my, wx, cy, SIDE_W, 24) && button == 0) {
                this.selected = cat;
                this.search = "";
                this.bindingModule = null;
                this.scroll = this.scrollTarget = 0f;
                return;
            }
            cy += 24;
        }
        if (!inside(mx, my, listX, listY, listW, listH)) {
            super.mouseClicked(mx, my, button);
            return;
        }
        for (Row r : buildRows()) {
            int ry = listY + r.y - (int) this.scroll;
            int x = listX, w = listW - 8;
            if (!inside(mx, my, x, ry, w, r.h)) continue;
            if (r.type != 4) this.bindingModule = null;
            switch (r.type) {
                case 4:
                    if (button == 0) {
                        this.bindingModule = this.bindingModule == r.module ? null : r.module;
                    }
                    break;
                case 0:
                    if (button == 0) {
                        r.module.toggle();
                    } else if (button == 1) {
                        if (!this.expanded.remove(r.module)) this.expanded.add(r.module);
                    }
                    break;
                case 1:
                    if (button == 0) {
                        BooleanProperty b = (BooleanProperty) r.prop;
                        b.setValue(!b.getValue());
                    }
                    break;
                case 2:
                    if (button == 0) {
                        this.dragging = r.prop;
                        this.dragX = x + 12;
                        this.dragW = w - 24;
                        setSliderPct(r.prop, (mx - dragX) / (float) dragW);
                    }
                    break;
                case 5:
                    if (button == 0) {
                        this.dragging = r.prop;
                        this.dragX = x + 12;
                        this.dragW = w - 24;
                        this.dragChannel = Math.max(0, Math.min(2, (my - (ry + 14)) / 9));
                        setColorChannel((ColorProperty) r.prop, this.dragChannel, (mx - dragX) / (float) dragW);
                    }
                    break;
                case 3:
                    if (button == 0) {
                        ((ModeProperty) r.prop).nextMode();
                    } else if (button == 1) {
                        ((ModeProperty) r.prop).previousMode();
                    }
                    break;
                default:
                    break;
            }
            return;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (this.bindingModule != null) {
            Module m = this.bindingModule;
            this.bindingModule = null;
            if (keyCode == Keyboard.KEY_ESCAPE) return;
            if (keyCode == Keyboard.KEY_DELETE || keyCode == Keyboard.KEY_BACK) {
                m.setKey(m instanceof GuiModule ? Keyboard.KEY_RSHIFT : 0);
            } else {
                m.setKey(keyCode);
            }
            return;
        }
        if (this.searchFocused) {
            if (keyCode == Keyboard.KEY_ESCAPE) {
                this.search = "";
                this.searchFocused = false;
            } else if (keyCode == Keyboard.KEY_RETURN) {
                this.searchFocused = false;
            } else if (keyCode == Keyboard.KEY_BACK) {
                if (!this.search.isEmpty()) this.search = this.search.substring(0, this.search.length() - 1);
            } else if (ChatAllowedCharacters.isAllowedCharacter(typedChar) && this.search.length() < 24) {
                this.search += typedChar;
            }
            this.scroll = this.scrollTarget = 0f;
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        if (state == 0) this.dragging = null;
        super.mouseReleased(mx, my, state);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            this.scrollTarget -= (wheel > 0 ? 1 : -1) * 28;
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
