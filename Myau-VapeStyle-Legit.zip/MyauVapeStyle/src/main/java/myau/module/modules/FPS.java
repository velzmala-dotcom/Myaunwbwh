package myau.module.modules;

import myau.event.EventTarget;
import myau.events.Render2DEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

/**
 * FPS - HUD element showing the current frames per second.
 */
public class FPS extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int BACKGROUND = 0x66000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int PADDING = 3;

    public final BooleanProperty renderBackground;
    public final IntProperty offsetX;
    public final IntProperty offsetY;
    public final FloatProperty scale;

    public FPS() {
        super("FPS", false);
        this.renderBackground = new BooleanProperty("render-background", true);
        this.offsetX = new IntProperty("offset-x", 4, 0, 2000);
        this.offsetY = new IntProperty("offset-y", 4, 0, 2000);
        this.scale = new FloatProperty("scale", 1.0F, 0.5F, 2.0F);
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null || mc.gameSettings.showDebugInfo) {
            return;
        }
        String text = Minecraft.getDebugFPS() + " FPS";
        float width = mc.fontRendererObj.getStringWidth(text) + PADDING * 2.0F;
        float height = mc.fontRendererObj.FONT_HEIGHT + PADDING * 2.0F - 1.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) this.offsetX.getValue(), (float) this.offsetY.getValue(), 0.0F);
        GlStateManager.scale(this.scale.getValue(), this.scale.getValue(), 1.0F);
        if (this.renderBackground.getValue()) {
            RenderUtil.enableRenderState();
            RenderUtil.drawRect(0.0F, 0.0F, width, height, BACKGROUND);
            RenderUtil.disableRenderState();
        }
        mc.fontRendererObj.drawString(text, PADDING, PADDING, TEXT_COLOR, true);
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }
}
