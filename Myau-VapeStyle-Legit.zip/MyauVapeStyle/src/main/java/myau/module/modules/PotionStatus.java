package myau.module.modules;

import myau.event.EventTarget;
import myau.events.Render2DEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * PotionStatus - HUD element listing active potion effects and their remaining duration.
 */
public class PotionStatus extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int BACKGROUND = 0x66000000;
    private static final int TEXT_DURATION = 0xFFAAAAAA;
    private static final int PADDING = 3;
    private static final int ROW_HEIGHT = 20;
    private static final int ROW_GAP = 2;

    public final BooleanProperty renderBackground;
    public final BooleanProperty showPositive;
    public final BooleanProperty showNegative;
    public final IntProperty offsetX;
    public final IntProperty offsetY;
    public final FloatProperty scale;

    public PotionStatus() {
        super("PotionStatus", false);
        this.renderBackground = new BooleanProperty("render-background", true);
        this.showPositive = new BooleanProperty("show-positive-effects", true);
        this.showNegative = new BooleanProperty("show-negative-effects", true);
        this.offsetX = new IntProperty("offset-x", 4, 0, 2000);
        this.offsetY = new IntProperty("offset-y", 60, 0, 2000);
        this.scale = new FloatProperty("scale", 1.0F, 0.5F, 2.0F);
    }

    private static String getName(PotionEffect effect, Potion potion) {
        String name = I18n.format(potion.getName());
        int amplifier = effect.getAmplifier();
        if (amplifier > 0) {
            String level = I18n.format("enchantment.level." + (amplifier + 1));
            name += " " + level;
        }
        return name;
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null || mc.gameSettings.showDebugInfo) {
            return;
        }
        Collection<PotionEffect> active = mc.thePlayer.getActivePotionEffects();
        if (active.isEmpty()) {
            return;
        }

        List<PotionEffect> effects = new ArrayList<>();
        for (PotionEffect effect : active) {
            Potion potion = effect.getPotionID() >= 0 && effect.getPotionID() < Potion.potionTypes.length
                    ? Potion.potionTypes[effect.getPotionID()]
                    : null;
            if (potion == null) {
                continue;
            }
            boolean bad = potion.isBadEffect();
            if (bad && !this.showNegative.getValue()) {
                continue;
            }
            if (!bad && !this.showPositive.getValue()) {
                continue;
            }
            effects.add(effect);
        }
        if (effects.isEmpty()) {
            return;
        }

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) this.offsetX.getValue(), (float) this.offsetY.getValue(), 0.0F);
        GlStateManager.scale(this.scale.getValue(), this.scale.getValue(), 1.0F);

        float y = 0.0F;
        for (PotionEffect effect : effects) {
            Potion potion = Potion.potionTypes[effect.getPotionID()];
            String name = getName(effect, potion);
            String duration = Potion.getDurationString(effect);
            float textWidth = Math.max(
                    mc.fontRendererObj.getStringWidth(name),
                    mc.fontRendererObj.getStringWidth(duration)
            );
            float width = PADDING + 18.0F + PADDING + textWidth + PADDING;

            if (this.renderBackground.getValue()) {
                RenderUtil.enableRenderState();
                RenderUtil.drawRect(0.0F, y, width, y + ROW_HEIGHT, BACKGROUND);
                RenderUtil.disableRenderState();
            }

            if (potion.hasStatusIcon()) {
                RenderUtil.renderPotionEffect(effect, PADDING, (int) y + 1);
            }

            int nameColor = 0xFF000000 | (potion.getLiquidColor() & 0xFFFFFF);
            // very dark potion colors are unreadable on the HUD, lighten them
            int r = nameColor >> 16 & 0xFF;
            int g = nameColor >> 8 & 0xFF;
            int b = nameColor & 0xFF;
            if (r + g + b < 240) {
                nameColor = 0xFFFFFFFF;
            }
            float textX = PADDING + 18.0F + PADDING;
            mc.fontRendererObj.drawString(name, textX, y + 2.0F, nameColor, true);
            mc.fontRendererObj.drawString(duration, textX, y + 11.0F, TEXT_DURATION, true);

            y += ROW_HEIGHT + ROW_GAP;
        }

        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }
}
