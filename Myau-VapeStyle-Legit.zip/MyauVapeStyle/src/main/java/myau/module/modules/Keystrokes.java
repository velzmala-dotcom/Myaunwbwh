package myau.module.modules;

import myau.event.EventTarget;
import myau.events.Render2DEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;

/**
 * Keystrokes - HUD element showing movement keys, mouse buttons and CPS.
 */
public class Keystrokes extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int KEY = 24;      // key size
    private static final int GAP = 2;       // gap between keys
    private static final int WIDTH = KEY * 3 + GAP * 2; // 76

    private static final int BG_NORMAL = 0x66000000;
    private static final int BG_PRESSED = 0xB3FFFFFF;
    private static final int TEXT_NORMAL = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFAAAAAA;
    private static final int TEXT_PRESSED = 0xFF111111;

    private final ArrayDeque<Long> leftClicks = new ArrayDeque<>();
    private final ArrayDeque<Long> rightClicks = new ArrayDeque<>();
    private boolean prevLeft = false;
    private boolean prevRight = false;

    public final ModeProperty keyStyle;
    public final ModeProperty mouseStyle;
    public final BooleanProperty showSpacebar;
    public final BooleanProperty showCpsOnly;
    public final BooleanProperty renderBackground;
    public final IntProperty offsetX;
    public final IntProperty offsetY;
    public final FloatProperty scale;

    public Keystrokes() {
        super("Keystrokes", false);
        this.keyStyle = new ModeProperty("key-style", 0, new String[]{"KEYBOARD", "ARROW"}, () -> !this.showCpsOnly.getValue());
        this.mouseStyle = new ModeProperty("mouse-style", 0, new String[]{"BUTTON", "ICON"}, () -> !this.showCpsOnly.getValue());
        this.showSpacebar = new BooleanProperty("show-spacebar", false, () -> !this.showCpsOnly.getValue());
        this.showCpsOnly = new BooleanProperty("show-cps-only", false);
        this.renderBackground = new BooleanProperty("render-background", true);
        this.offsetX = new IntProperty("offset-x", 10, 0, 2000);
        this.offsetY = new IntProperty("offset-y", 100, 0, 2000);
        this.scale = new FloatProperty("scale", 1.0F, 0.5F, 2.0F);
    }

    // ------------------------------------------------------------------ click counting

    private static int purge(ArrayDeque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000L) {
            clicks.pollFirst();
        }
        return clicks.size();
    }

    // ------------------------------------------------------------------ drawing helpers

    private void box(float x, float y, float w, float h, boolean pressed) {
        int color;
        if (pressed) {
            color = this.renderBackground.getValue() ? BG_PRESSED : 0;
        } else {
            color = this.renderBackground.getValue() ? BG_NORMAL : 0;
        }
        if (color == 0) return;
        RenderUtil.enableRenderState();
        RenderUtil.drawRect(x, y, x + w, y + h, color);
        RenderUtil.disableRenderState();
    }

    private int textColor(boolean pressed) {
        if (this.renderBackground.getValue()) {
            return pressed ? TEXT_PRESSED : TEXT_NORMAL;
        }
        return pressed ? TEXT_NORMAL : TEXT_DIM;
    }

    private void text(String s, float cx, float cy, int color, float size) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, 0.0F);
        GlStateManager.scale(size, size, 1.0F);
        float w = mc.fontRendererObj.getStringWidth(s);
        mc.fontRendererObj.drawString(s, -w / 2.0F, -mc.fontRendererObj.FONT_HEIGHT / 2.0F + 1.0F, color, false);
        GlStateManager.popMatrix();
    }

    /** Arrow whose tip points to the given screen direction (radians, y down). */
    private void arrow(float cx, float cy, float tipDirection, int color) {
        // drawTriangle draws from the tip (center) towards "angle", so use the opposite direction
        float a = tipDirection + (float) Math.PI;
        float len = 9.0F;
        float tx = cx - (float) Math.cos(a) * len / 2.0F;
        float ty = cy - (float) Math.sin(a) * len / 2.0F;
        RenderUtil.enableRenderState();
        RenderUtil.drawTriangle(tx, ty, a, len, color);
        RenderUtil.disableRenderState();
    }

    private void moveKey(float x, float y, String letter, float arrowDir, boolean pressed) {
        this.box(x, y, KEY, KEY, pressed);
        int color = this.textColor(pressed);
        if (this.keyStyle.getValue() == 0) {
            this.text(letter, x + KEY / 2.0F, y + KEY / 2.0F, color, 1.0F);
        } else {
            this.arrow(x + KEY / 2.0F, y + KEY / 2.0F, arrowDir, color);
        }
    }

    // ------------------------------------------------------------------ render

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;

        long now = System.currentTimeMillis();
        boolean left = Mouse.isButtonDown(0);
        boolean right = Mouse.isButtonDown(1);
        if (left && !this.prevLeft) this.leftClicks.addLast(now);
        if (right && !this.prevRight) this.rightClicks.addLast(now);
        this.prevLeft = left;
        this.prevRight = right;
        int lcps = purge(this.leftClicks, now);
        int rcps = purge(this.rightClicks, now);

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) this.offsetX.getValue(), (float) this.offsetY.getValue(), 0.0F);
        GlStateManager.scale(this.scale.getValue(), this.scale.getValue(), 1.0F);

        if (this.showCpsOnly.getValue()) {
            this.box(0, 0, WIDTH, 18, false);
            this.text(lcps + " | " + rcps + " CPS", WIDTH / 2.0F, 9.0F, TEXT_NORMAL, 1.0F);
        } else {
            boolean w = mc.gameSettings.keyBindForward.isKeyDown();
            boolean a = mc.gameSettings.keyBindLeft.isKeyDown();
            boolean s = mc.gameSettings.keyBindBack.isKeyDown();
            boolean d = mc.gameSettings.keyBindRight.isKeyDown();

            this.moveKey(KEY + GAP, 0, "W", (float) (Math.PI / 2.0 * -1.0), w);        // up
            this.moveKey(0, KEY + GAP, "A", (float) Math.PI, a);                        // left
            this.moveKey(KEY + GAP, KEY + GAP, "S", (float) (Math.PI / 2.0), s);        // down
            this.moveKey((KEY + GAP) * 2, KEY + GAP, "D", 0.0F, d);                     // right

            float y = (KEY + GAP) * 2;
            if (this.showSpacebar.getValue()) {
                boolean space = mc.gameSettings.keyBindJump.isKeyDown();
                this.box(0, y, WIDTH, 16, space);
                RenderUtil.enableRenderState();
                RenderUtil.drawRect(WIDTH / 2.0F - 14, y + 7, WIDTH / 2.0F + 14, y + 9, this.textColor(space));
                RenderUtil.disableRenderState();
                y += 16 + GAP;
            }

            if (this.mouseStyle.getValue() == 0) {
                float bw = (WIDTH - GAP) / 2.0F;
                this.box(0, y, bw, KEY, left);
                this.box(bw + GAP, y, bw, KEY, right);
                this.text("LMB", bw / 2.0F, y + 8, this.textColor(left), 1.0F);
                this.text(lcps + " CPS", bw / 2.0F, y + 17, this.textColor(left), 0.7F);
                this.text("RMB", bw + GAP + bw / 2.0F, y + 8, this.textColor(right), 1.0F);
                this.text(rcps + " CPS", bw + GAP + bw / 2.0F, y + 17, this.textColor(right), 0.7F);
            } else {
                float bodyX = (WIDTH - 40) / 2.0F;
                float half = 19.0F;
                this.box(bodyX, y, half, 22, left);
                this.box(bodyX + half + 2, y, half, 22, right);
                this.box(bodyX, y + 24, 40, 20, false);
                this.text(lcps + " | " + rcps, WIDTH / 2.0F, y + 34, TEXT_NORMAL, 0.8F);
            }
        }
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }
}
