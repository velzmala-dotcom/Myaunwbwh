package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/**
 * FreeLook - detached third-person camera. The mouse moves only the camera,
 * the player keeps facing (and moving) in the original direction.
 *
 * The camera state is kept in static fields that MixinEntity (setAngles) and
 * MixinEntityRenderer (orientCamera) read.
 */
public class FreeLook extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    // ---- camera state read by the mixins
    public static boolean active = false;
    public static float cameraYaw = 0.0F;
    public static float cameraPitch = 0.0F;

    private int previousView = 0;

    public final ModeProperty activate;
    public final ModeProperty startingPosition;
    public final BooleanProperty useCustomSensitivity;
    public final IntProperty sensitivity;

    public FreeLook() {
        super("FreeLook", false);
        this.activate = new ModeProperty("activate-freelook", 0, new String[]{"HOLD", "TOGGLE"});
        this.startingPosition = new ModeProperty("starting-position", 0, new String[]{"FORWARD", "BACKWARD"});
        this.useCustomSensitivity = new BooleanProperty("use-custom-sensitivity", false);
        this.sensitivity = new IntProperty("sensitivity", 50, 0, 100, this.useCustomSensitivity::getValue);
    }

    // ------------------------------------------------------------------ mixin API

    /** Called from MixinEntity#setAngles with the already-scaled mouse delta. */
    public static void rotate(float yaw, float pitch) {
        float ratio = 1.0F;
        FreeLook module = getInstance();
        if (module != null && module.useCustomSensitivity.getValue()) {
            float game = sensitivityFactor(mc.gameSettings.mouseSensitivity);
            float custom = sensitivityFactor(module.sensitivity.getValue() / 100.0F);
            if (game > 0.0F) {
                ratio = custom / game;
            }
        }
        cameraYaw += yaw * ratio * 0.15F;
        cameraPitch -= pitch * ratio * 0.15F;
        if (cameraPitch > 90.0F) cameraPitch = 90.0F;
        if (cameraPitch < -90.0F) cameraPitch = -90.0F;
    }

    private static float sensitivityFactor(float s) {
        float f = s * 0.6F + 0.2F;
        return f * f * f * 8.0F;
    }

    private static FreeLook getInstance() {
        return (FreeLook) myau.Myau.moduleManager.modules.get(FreeLook.class);
    }

    // ------------------------------------------------------------------ logic

    private boolean isKeyHeld() {
        int key = this.getKey();
        if (key == 0) return true; // enabled from the GUI: nothing to release
        if (key < 0) return Mouse.isButtonDown(key + 100);
        return Keyboard.isKeyDown(key);
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) return;
        if (mc.thePlayer == null || mc.theWorld == null) {
            this.setEnabled(false);
            return;
        }
        // keep the detached 3rd person view while active (F5 would change it)
        if (mc.gameSettings.thirdPersonView != 1) {
            mc.gameSettings.thirdPersonView = 1;
        }
        // HOLD: turn off as soon as the key is released
        if (this.activate.getValue() == 0 && mc.currentScreen == null && !this.isKeyHeld()) {
            this.setEnabled(false);
        }
    }

    @Override
    public void onEnabled() {
        if (mc.thePlayer == null) {
            this.setEnabled(false);
            return;
        }
        this.previousView = mc.gameSettings.thirdPersonView;
        mc.gameSettings.thirdPersonView = 1;
        cameraYaw = mc.thePlayer.rotationYaw;
        cameraPitch = mc.thePlayer.rotationPitch;
        if (this.startingPosition.getValue() == 1) {
            // camera in front of the player, looking back at him
            cameraYaw += 180.0F;
            cameraPitch = -cameraPitch;
        }
        active = true;
    }

    @Override
    public void onDisabled() {
        active = false;
        if (mc.gameSettings != null) {
            mc.gameSettings.thirdPersonView = this.previousView;
        }
    }
}
