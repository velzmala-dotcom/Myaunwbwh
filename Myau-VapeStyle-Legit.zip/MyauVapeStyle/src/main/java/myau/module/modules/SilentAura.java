package myau.module.modules;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.MoveInputEvent;
import myau.events.Render3DEvent;
import myau.events.StrafeEvent;
import myau.events.UpdateEvent;
import myau.management.RotationState;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.ColorProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.property.properties.TextProperty;
import myau.util.ItemUtil;
import myau.util.MoveFixUtil;
import myau.util.MovementCorrector;
import myau.util.PlayerUtil;
import myau.util.RenderUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

public class SilentAura extends Module {
   private static final Minecraft mc = Minecraft.func_71410_x();
   public final ModeProperty movement = new ModeProperty("movement", 0, new String[]{"PROPER", "SLOW", "NONE"});
   public final BooleanProperty thirdPersonAimView = new BooleanProperty("third-person-aim-view", true);
   public final BooleanProperty aimIndicator = new BooleanProperty("aim-indicator", false);
   public final BooleanProperty targetPlayers = new BooleanProperty("target-players", true);
   public final BooleanProperty targetMobs = new BooleanProperty("target-mobs", false);
   public final BooleanProperty targetAnimals = new BooleanProperty("target-animals", false);
   public final BooleanProperty ignoreInvisible = new BooleanProperty("ignore-invisible", true);
   public final BooleanProperty ignoreNaked = new BooleanProperty("ignore-naked", false);
   public final BooleanProperty ignoreBehindWalls = new BooleanProperty("ignore-behind-walls", false);
   public final BooleanProperty ignoreTeammates = new BooleanProperty("ignore-teammates", true);
   public final BooleanProperty ignoreFriends = new BooleanProperty("ignore-friends", true);
   public final FloatProperty aimSpeed = new FloatProperty("aim-speed", 5.0F, 1.0F, 10.0F);
   public final FloatProperty maxAngle = new FloatProperty("max-angle", 180.0F, 1.0F, 180.0F);
   public final FloatProperty aimRange = new FloatProperty("aim-range", 5.0F, 2.0F, 10.0F);
   public final ModeProperty targetMode = new ModeProperty("target-mode", 0, new String[]{"DISTANCE", "YAW", "ARMOR", "THREAT", "HEALTH"});
   public final ModeProperty targetArea = new ModeProperty("target-area", 0, new String[]{"CENTER", "CLOSEST"});
   public final IntProperty minAps = new IntProperty("min-aps", 8, 1, 20);
   public final IntProperty maxAps = new IntProperty("max-aps", 12, 1, 20);
   public final FloatProperty attackRange = new FloatProperty("attack-range", 3.0F, 2.0F, 6.0F);
   public final FloatProperty extraSwingDistance = new FloatProperty("extra-swing-distance", 0.5F, 0.0F, 3.0F);
   public final BooleanProperty breakBlocks = new BooleanProperty("break-blocks", false);
   public final IntProperty breakDelayMin = new IntProperty("break-blocks-delay-min", 100, 0, 1000, () -> (Boolean)this.breakBlocks.getValue());
   public final IntProperty breakDelayMax = new IntProperty("break-blocks-delay-max", 200, 0, 1000, () -> (Boolean)this.breakBlocks.getValue());
   public final TextProperty breakWhitelist = new TextProperty("break-blocks-whitelist", "pickaxes,shovels,axes", () -> (Boolean)this.breakBlocks.getValue());
   public final BooleanProperty requireMouseDown = new BooleanProperty("require-mouse-down", false);
   public final BooleanProperty disableOnDeath = new BooleanProperty("disable-on-death", true);
   public final BooleanProperty showTarget = new BooleanProperty("show-target", false);
   public final ColorProperty targetColor = new ColorProperty("target-color", 5614335, () -> (Boolean)this.showTarget.getValue());
   public final ColorProperty attackColor = new ColorProperty("attack-color", 16733525, () -> (Boolean)this.showTarget.getValue());
   private final Random rng = new Random();
   private EntityLivingBase target = null;
   private boolean rotating = false;
   private boolean acted = false;
   private float silentYaw = 0.0F;
   private float silentPitch = 0.0F;
   private double aimX;
   private double aimY;
   private double aimZ;
   private long nextAttackAt = 0L;
   private long lastAttackAt = 0L;
   private long breakSince = 0L;
   private long breakDelay = 0L;
   public final ModeProperty moveFix = new ModeProperty("move-fix", 0, new String[]{"SILENT", "STRICT", "NONE"});

   public SilentAura() {
      super("SilentAura", false);
   }

   public String[] getSuffix() {
      return new String[]{this.movement.getModeString()};
   }

   public void onDisabled() {
      this.reset();
   }

   private void reset() {
      this.target = null;
      this.rotating = false;
      this.acted = false;
      this.nextAttackAt = 0L;
      this.breakSince = 0L;
   }

   private boolean ready() {
      return mc.field_71439_g != null && mc.field_71441_e != null && mc.field_71462_r == null;
   }

   private static float wrap180(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   private static double clamp(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   private boolean holdingListed(String var1) {
      if (var1 != null && !var1.trim().isEmpty()) {
         ItemStack var2 = mc.field_71439_g.func_70694_bm();
         String var3 = var2 == null ? "" : var2.func_82833_r().toLowerCase();
         List var4 = Arrays.asList(var3.split("[^a-z0-9]+"));

         for(String var8 : var1.split(",")) {
            String var9 = var8.trim().toLowerCase();
            if (!var9.isEmpty()) {
               if (!var9.equals("fists") && !var9.equals("fist") && !var9.equals("hand") && !var9.equals("empty")) {
                  if (var2 != null) {
                     if ((var9.equals("swords") || var9.equals("sword")) && ItemUtil.isHoldingSword()) {
                        return true;
                     }

                     if ((var9.equals("tools") || var9.equals("tool")) && ItemUtil.isHoldingTool()) {
                        return true;
                     }

                     if ((var9.equals("blocks") || var9.equals("block")) && ItemUtil.isHoldingBlock()) {
                        return true;
                     }

                     String var10 = var9.endsWith("s") ? var9.substring(0, var9.length() - 1) : var9;
                     if (var4.contains(var9) || var4.contains(var10) || var9.contains(" ") && var3.contains(var9)) {
                        return true;
                     }
                  }
               } else if (var2 == null) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private boolean paused() {
      if ((Boolean)this.requireMouseDown.getValue() && !PlayerUtil.isAttacking()) {
         this.breakSince = 0L;
         return true;
      } else {
         if ((Boolean)this.breakBlocks.getValue()) {
            MovingObjectPosition var1 = mc.field_71476_x;
            boolean var2 = var1 != null && var1.field_72313_a == MovingObjectType.BLOCK;
            if (var2 && PlayerUtil.isAttacking() && this.holdingListed((String)this.breakWhitelist.getValue())) {
               long var3 = System.currentTimeMillis();
               if (this.breakSince == 0L) {
                  this.breakSince = var3;
                  int var5 = Math.min((Integer)this.breakDelayMin.getValue(), (Integer)this.breakDelayMax.getValue());
                  int var6 = Math.max((Integer)this.breakDelayMin.getValue(), (Integer)this.breakDelayMax.getValue());
                  this.breakDelay = (long)var5 + (var6 > var5 ? (long)this.rng.nextInt(var6 - var5 + 1) : 0L);
               }

               return var3 - this.breakSince >= this.breakDelay;
            }
         }

         this.breakSince = 0L;
         return false;
      }
   }

   private double[] eye() {
      return new double[]{mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v};
   }

   private double[] aimPoint(Entity var1, double[] var2) {
      AxisAlignedBB var3 = var1.func_174813_aQ();
      double var4 = (var3.field_72340_a + var3.field_72336_d) / (double)2.0F;
      double var6 = (var3.field_72338_b + var3.field_72337_e) / (double)2.0F;
      double var8 = (var3.field_72339_c + var3.field_72334_f) / (double)2.0F;
      if ((Integer)this.targetArea.getValue() == 1) {
         double var10 = clamp(var2[0], var3.field_72340_a, var3.field_72336_d);
         double var12 = clamp(var2[1], var3.field_72338_b, var3.field_72337_e);
         double var14 = clamp(var2[2], var3.field_72339_c, var3.field_72334_f);
         if (var10 != var2[0] || var12 != var2[1] || var14 != var2[2]) {
            return new double[]{var10, var12, var14};
         }
      }

      return new double[]{var4, var6, var8};
   }

   private static float[] anglesTo(double[] var0, double[] var1) {
      double var2 = var1[0] - var0[0];
      double var4 = var1[1] - var0[1];
      double var6 = var1[2] - var0[2];
      float var8 = (float)(Math.atan2(var6, var2) * (double)180.0F / Math.PI) - 90.0F;
      float var9 = (float)(-(Math.atan2(var4, Math.hypot(var2, var6)) * (double)180.0F / Math.PI));
      return new float[]{var8, var9};
   }

   private boolean validType(Entity var1) {
      if (var1 != mc.field_71439_g && var1 instanceof EntityLivingBase) {
         EntityLivingBase var2 = (EntityLivingBase)var1;
         if (!(var2.func_110143_aJ() <= 0.0F) && !var2.field_70128_L && TeamUtil.isEntityLoaded(var1)) {
            if (var1.func_82150_aj() && (Boolean)this.ignoreInvisible.getValue()) {
               return false;
            } else if (TeamUtil.isShop(var2)) {
               return false;
            } else if (var1 instanceof EntityPlayer) {
               EntityPlayer var3 = (EntityPlayer)var1;
               if ((Boolean)this.targetPlayers.getValue() && !TeamUtil.isBot(var3)) {
                  if ((Boolean)this.ignoreTeammates.getValue() && TeamUtil.isSameTeam(var3)) {
                     return false;
                  } else if ((Boolean)this.ignoreFriends.getValue() && TeamUtil.isFriend(var3)) {
                     return false;
                  } else {
                     return !(Boolean)this.ignoreNaked.getValue() || var3.func_70658_aO() > 0;
                  }
               } else {
                  return false;
               }
            } else if (var1 instanceof IMob) {
               return (Boolean)this.targetMobs.getValue();
            } else {
               return var1 instanceof EntityAnimal ? (Boolean)this.targetAnimals.getValue() : false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean visible(Entity var1, double[] var2, double[] var3) {
      Vec3 var4 = new Vec3(var2[0], var2[1], var2[2]);
      Vec3 var5 = new Vec3(var3[0], var3[1], var3[2]);
      return mc.field_71441_e.func_72933_a(var4, var5) == null;
   }

   private double score(EntityLivingBase var1, double var2, float var4) {
      switch ((Integer)this.targetMode.getValue()) {
         case 1:
            return (double)var4;
         case 2:
            return (double)var1.func_70658_aO() + var2 * 0.001;
         case 3:
            double var5 = (double)0.0F;
            if (var1 instanceof EntityPlayer) {
               ItemStack var7 = var1.func_70694_bm();
               if (var7 != null) {
                  var5 = ItemUtil.getAttackBonus(var7);
               }
            }

            return -var5 + var2 * 0.001;
         case 4:
            return (double)var1.func_110143_aJ() + var2 * 0.001;
         default:
            return var2;
      }
   }

   private EntityLivingBase pickTarget(double[] var1) {
      EntityLivingBase var2 = null;
      double var3 = Double.MAX_VALUE;
      double var5 = (double)(Float)this.aimRange.getValue();
      float var7 = mc.field_71439_g.field_70177_z;

      for(Entity var9 : TeamUtil.getLoadedEntitiesSorted()) {
         if (this.validType(var9)) {
            double var10 = RotationUtil.distanceToEntity(var9);
            if (!(var10 > var5)) {
               double[] var12 = this.aimPoint(var9, var1);
               float[] var13 = anglesTo(var1, var12);
               float var14 = Math.abs(wrap180(var13[0] - var7));
               if (!(var14 > (Float)this.maxAngle.getValue()) && (!(Boolean)this.ignoreBehindWalls.getValue() || this.visible(var9, var1, var12))) {
                  double var15 = this.score((EntityLivingBase)var9, var10, var14);
                  if (var15 < var3) {
                     var3 = var15;
                     var2 = (EntityLivingBase)var9;
                  }
               }
            }
         }
      }

      return var2;
   }

   private long nextDelay() {
      int var1 = Math.min((Integer)this.minAps.getValue(), (Integer)this.maxAps.getValue());
      int var2 = Math.max((Integer)this.minAps.getValue(), (Integer)this.maxAps.getValue());
      double var3 = (double)var1 + this.rng.nextDouble() * (double)(var2 - var1);
      var3 = Math.max((double)1.0F, var3);
      return (long)((double)1000.0F / var3);
   }

   private boolean hovering(Entity var1, float var2, float var3, double var4) {
      double[] var6 = this.eye();
      Vec3 var7 = new Vec3(var6[0], var6[1], var6[2]);
      double var8 = Math.cos((double)(-var2 * ((float)Math.PI / 180F)) - Math.PI);
      double var10 = Math.sin((double)(-var2 * ((float)Math.PI / 180F)) - Math.PI);
      double var12 = -Math.cos((double)(-var3 * ((float)Math.PI / 180F)));
      double var14 = Math.sin((double)(-var3 * ((float)Math.PI / 180F)));
      double var16 = var10 * var12;
      double var20 = var8 * var12;
      Vec3 var22 = var7.func_72441_c(var16 * var4, var14 * var4, var20 * var4);
      float var23 = var1.func_70111_Y();
      AxisAlignedBB var24 = var1.func_174813_aQ().func_72314_b((double)var23, (double)var23, (double)var23);
      MovingObjectPosition var25 = var24.func_72327_a(var7, var22);
      if (var25 != null) {
         if (var25.field_72307_f == null) {
            return true;
         } else {
            MovingObjectPosition var26 = mc.field_71441_e.func_72933_a(var7, var25.field_72307_f);
            return var26 == null;
         }
      } else {
         return var6[0] >= var24.field_72340_a && var6[0] <= var24.field_72336_d && var6[1] >= var24.field_72338_b && var6[1] <= var24.field_72337_e && var6[2] >= var24.field_72339_c && var6[2] <= var24.field_72334_f;
      }
   }

   @EventTarget
   public void onUpdate(UpdateEvent var1) {
      if (var1.getType() == EventType.PRE) {
         this.acted = false;
         if (!this.isEnabled()) {
            return;
         }

         if (!this.ready()) {
            this.reset();
            return;
         }

         if ((Boolean)this.disableOnDeath.getValue() && (mc.field_71439_g.func_110143_aJ() <= 0.0F || mc.field_71439_g.field_70725_aQ > 0)) {
            this.setEnabled(false);
            return;
         }

         double[] var2 = this.eye();
         this.target = this.paused() ? null : this.pickTarget(var2);
         float var3 = var1.getYaw();
         float var4 = var1.getPitch();
         float var5;
         float var6;
         if (this.target != null) {
            double[] var7 = this.aimPoint(this.target, var2);
            this.aimX = var7[0];
            this.aimY = var7[1];
            this.aimZ = var7[2];
            float[] var8 = anglesTo(var2, var7);
            var5 = var8[0];
            var6 = var8[1];
         } else {
            if (!this.rotating) {
               return;
            }

            var5 = var1.getNewYaw();
            var6 = var1.getNewPitch();
            if (Math.abs(wrap180(var5 - var3)) < 1.0F && Math.abs(var6 - var4) < 1.0F) {
               this.rotating = false;
               return;
            }
         }

         float var16 = (Float)this.aimSpeed.getValue();
         float var17 = Math.min(1.0F, 0.25F + 0.075F * var16);
         float var9 = 30.0F + var16 * 15.0F;
         float var10 = wrap180(var5 - var3);
         float var11 = var6 - var4;
         float var12 = (float)clamp((double)(var10 * var17), (double)(-var9), (double)var9);
         float var13 = (float)clamp((double)(var11 * var17), (double)(-var9), (double)var9);
         if (var17 < 1.0F) {
            var12 += (this.rng.nextFloat() - 0.5F) * 0.3F;
            var13 += (this.rng.nextFloat() - 0.5F) * 0.15F;
         }

         float var14 = var3 + RotationUtil.quantizeAngle(var12);
         float var15 = (float)clamp((double)(var4 + RotationUtil.quantizeAngle(var13)), (double)-90.0F, (double)90.0F);
         this.silentYaw = var14;
         this.silentPitch = var15;
         this.rotating = true;
         this.acted = true;
         var1.setRotation(var14, var15, 3);
         if (true) {
            var1.setPervRotation(MoveFixUtil.headingFromAim(var14, this.moveFix, mc.field_71439_g.field_70177_z), 3);
         }
      } else if (var1.getType() == EventType.POST) {
         if (!this.acted || !this.isEnabled() || !this.ready()) {
            return;
         }

         this.acted = false;
         this.attack();
         if (!(Boolean)this.thirdPersonAimView.getValue()) {
            RotationState.applyState(false, 0.0F, 0.0F, 0.0F, 0);
            RotationState.applyState(false, 0.0F, 0.0F, 0.0F, 0);
         }
      }

   }

   private void attack() {
      EntityLivingBase var1 = this.target;
      if (var1 != null && !PlayerUtil.isUsingItem()) {
         long var2 = System.currentTimeMillis();
         if (var2 >= this.nextAttackAt) {
            double var4 = (double)(Float)this.attackRange.getValue();
            double var6 = RotationUtil.distanceToEntity(var1);
            if (!(var6 > var4 + (double)(Float)this.extraSwingDistance.getValue())) {
               if (var6 <= var4 && this.hovering(var1, this.silentYaw, this.silentPitch, var4)) {
                  mc.field_71439_g.func_71038_i();
                  mc.field_71442_b.func_78764_a(mc.field_71439_g, var1);
                  this.lastAttackAt = var2;
                  this.nextAttackAt = var2 + this.nextDelay();
               } else if (var6 > var4) {
                  mc.field_71439_g.func_71038_i();
                  this.nextAttackAt = var2 + this.nextDelay();
               }

            }
         }
      }
   }

   @EventTarget
   public void onStrafe(StrafeEvent var1) {
      if (this.isEnabled() && this.rotating) {
         MovementCorrector.apply(var1, 0, mc.field_71439_g.field_70177_z, RotationState.getSmoothedYaw());
         if ((Integer)this.movement.getValue() == 1) {
            var1.setStrafe(var1.getStrafe() * 0.6F);
            var1.setForward(var1.getForward() * 0.6F);
         }

      }
   }

   @EventTarget
   public void onRender3D(Render3DEvent var1) {
      if (this.isEnabled() && this.ready() && this.target != null) {
         boolean var2 = (Boolean)this.showTarget.getValue();
         boolean var3 = (Boolean)this.aimIndicator.getValue() && this.rotating;
         if (var2 || var3) {
            RenderUtil.enableRenderState();
            if (var2) {
               int var4 = System.currentTimeMillis() - this.lastAttackAt < 250L ? (Integer)this.attackColor.getValue() : (Integer)this.targetColor.getValue();
               RenderUtil.drawEntityBoundingBox(this.target, var4 >> 16 & 255, var4 >> 8 & 255, var4 & 255, 170, 2.0F, 0.1);
            }

            if (var3) {
               Entity var9 = mc.func_175606_aa();
               if (var9 != null) {
                  float var5 = var9.field_70127_C + (var9.field_70125_A - var9.field_70127_C) * var1.getPartialTicks();
                  float var6 = var9.field_70126_B + (var9.field_70177_z - var9.field_70126_B) * var1.getPartialTicks();
                  Vec3 var7 = (new Vec3((double)0.0F, (double)0.0F, (double)1.0F)).func_178789_a((float)Math.toRadians((double)(-var5))).func_178785_b((float)Math.toRadians((double)(-var6)));
                  Vec3 var8 = new Vec3(var7.field_72450_a, var7.field_72448_b + (double)var9.func_70047_e(), var7.field_72449_c);
                  RenderUtil.drawLine3D(var8, this.aimX, this.aimY, this.aimZ, 1.0F, 0.33F, 0.33F, 1.0F, 1.5F);
               }
            }

            RenderUtil.disableRenderState();
         }
      }
   }

   @EventTarget
   public void onMoveInput(MoveInputEvent var1) {
      MoveFixUtil.apply(this.moveFix, this, 3);
   }
}
