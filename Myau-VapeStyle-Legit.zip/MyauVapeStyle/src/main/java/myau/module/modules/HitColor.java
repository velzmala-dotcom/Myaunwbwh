package myau.module.modules;

import myau.module.Module;
import myau.property.properties.ColorProperty;

/**
 * HitColor - changes the color entities flash when they are hurt
 * (default is the vanilla blood red). The actual color swap happens in
 * MixinRendererLivingEntity#setBrightness, which reads channel().
 */
public class HitColor extends Module {
    public final ColorProperty color;

    public HitColor() {
        super("HitColor", false);
        this.color = new ColorProperty("color", 0xFF0000);
    }

    /** 0 = red, 1 = green, 2 = blue, returned as 0.0 - 1.0. */
    public float channel(int index) {
        int rgb = this.color.getValue() & 0xFFFFFF;
        int shift = 16 - index * 8;
        return ((rgb >> shift) & 0xFF) / 255.0F;
    }
}
