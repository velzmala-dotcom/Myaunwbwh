package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.LoadWorldEvent;
import myau.events.PacketEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.IntProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.S03PacketTimeUpdate;

/**
 * TimeChanger - overrides the time of day client-side only.
 * Time values: 0 = sunrise, 6000 = noon, 12000 = sunset, 18000 = midnight.
 */
public class TimeChanger extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final long DAY = 24000L;

    private long baseTime = Long.MIN_VALUE;

    public final IntProperty time;

    public TimeChanger() {
        super("TimeChanger", false);
        this.time = new IntProperty("time", 6000, 0, 24000);
    }

    private void captureBase() {
        if (mc.theWorld != null) {
            this.baseTime = Math.floorDiv(mc.theWorld.getWorldTime(), DAY) * DAY;
        }
    }

    @Override
    public void onEnabled() {
        this.baseTime = Long.MIN_VALUE;
        this.captureBase();
    }

    @Override
    public void onDisabled() {
        this.baseTime = Long.MIN_VALUE;
        // the server resends the real time every second, so it restores itself
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.baseTime = Long.MIN_VALUE;
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (this.isEnabled() && event.getType() == EventType.RECEIVE && !event.isCancelled()) {
            if (event.getPacket() instanceof S03PacketTimeUpdate) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.POST || mc.theWorld == null) {
            return;
        }
        if (this.baseTime == Long.MIN_VALUE) {
            this.captureBase();
        }
        mc.theWorld.setWorldTime(this.baseTime + (long) this.time.getValue());
    }
}
