package myau.module.modules;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.LoadWorldEvent;
import myau.events.PacketEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;

public class BackTrack extends Module {
   private static final Minecraft mc = Minecraft.func_71410_x();
   public final IntProperty delay = new IntProperty("delay", 150, 20, 1000);
   public final FloatProperty range = new FloatProperty("range", 6.0F, 3.0F, 10.0F);
   public final IntProperty combatTime = new IntProperty("combat-time", 2000, 500, 10000);
   private static final ConcurrentHashMap<Class<?>, Field> ID_FIELDS = new ConcurrentHashMap();
   private final ConcurrentLinkedQueue<Held> queue = new ConcurrentLinkedQueue();
   private volatile EntityPlayer target = null;
   private volatile long lastAttack = 0L;

   public BackTrack() {
      super("BackTrack", false);
   }

   public void onDisabled() {
      this.flushAll();
      this.target = null;
   }

   public String[] getSuffix() {
      return new String[]{this.delay.getValue() + "ms"};
   }

   @EventTarget
   public void onAttack(AttackEvent var1) {
      if (this.isEnabled() && !var1.isCancelled()) {
         Entity var2 = var1.getTarget();
         if (var2 instanceof EntityPlayer && var2 != mc.field_71439_g) {
            if (this.target != var2) {
               this.flushAll();
               this.target = (EntityPlayer)var2;
            }

            this.lastAttack = System.currentTimeMillis();
         }
      }
   }

   @EventTarget
   public void onPacket(PacketEvent var1) {
      if (this.isEnabled() && var1.getType() == EventType.RECEIVE && !var1.isCancelled()) {
         EntityPlayer var2 = this.target;
         if (var2 != null) {
            Packet var3 = var1.getPacket();
            if (var3 instanceof S14PacketEntity || var3 instanceof S18PacketEntityTeleport) {
               if (entityId(var3) == var2.func_145782_y()) {
                  if (!this.queue.isEmpty() || this.shouldDelay(var2)) {
                     this.queue.add(new Held(var3, System.currentTimeMillis()));
                     var1.setCancelled(true);
                  }

               }
            }
         }
      }
   }

   @EventTarget
   public void onTick(TickEvent var1) {
      if (var1.getType() == EventType.PRE && !this.queue.isEmpty()) {
         EntityPlayer var2 = this.target;
         if (this.isEnabled() && var2 != null && mc.field_71439_g != null && mc.field_71441_e != null && this.shouldDelay(var2)) {
            long var3 = System.currentTimeMillis();
            long var5 = (long)(Integer)this.delay.getValue();

            Held var7;
            while((var7 = (Held)this.queue.peek()) != null && var3 - var7.time >= var5) {
               this.queue.poll();
               process(var7.packet);
            }

         } else {
            this.flushAll();
         }
      }
   }

   @EventTarget
   public void onLoadWorld(LoadWorldEvent var1) {
      this.queue.clear();
      this.target = null;
   }

   private boolean shouldDelay(EntityPlayer var1) {
      if (mc.field_71439_g != null && mc.field_71441_e != null) {
         if (var1.field_70725_aQ <= 0 && !(var1.func_110143_aJ() <= 0.0F)) {
            if (System.currentTimeMillis() - this.lastAttack > (long)(Integer)this.combatTime.getValue()) {
               return false;
            } else {
               return mc.field_71439_g.func_70032_d(var1) <= (Float)this.range.getValue();
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void flushAll() {
      Held var1;
      while((var1 = (Held)this.queue.poll()) != null) {
         process(var1.packet);
      }

   }

   private static void process(Packet var0) {
      try {
         if (mc.func_147114_u() != null && mc.field_71441_e != null) {
            var0.func_148833_a(mc.func_147114_u());
         }
      } catch (Throwable var2) {
      }

   }

   private static int entityId(Packet<?> var0) {
      try {
         Class var1 = var0.getClass();
         Field var2 = (Field)ID_FIELDS.get(var1);
         if (var2 == null) {
            for(Class var3 = var1; var3 != null && var3 != Object.class && var2 == null; var3 = var3.getSuperclass()) {
               for(Field var7 : var3.getDeclaredFields()) {
                  if (var7.getType() == Integer.TYPE && !Modifier.isStatic(var7.getModifiers())) {
                     var2 = var7;
                     break;
                  }
               }
            }

            if (var2 == null) {
               return -1;
            }

            var2.setAccessible(true);
            ID_FIELDS.put(var1, var2);
         }

         return var2.getInt(var0);
      } catch (Throwable var8) {
         return -1;
      }
   }

   private static final class Held {
      final Packet<?> packet;
      final long time;

      Held(Packet<?> var1, long var2) {
         this.packet = var1;
         this.time = var2;
      }
   }
}
