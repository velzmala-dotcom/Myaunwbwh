package myau.module.modules;

import myau.event.EventTarget;
import myau.events.AttackEvent;
import myau.events.LoadWorldEvent;
import myau.events.Render2DEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

/**
 * ReachDisplay - HUD element showing the distance to your opponent at the time you last landed a hit.
 */
public class ReachDisplay extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final int BACKGROUND = 0x66000000;
    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int PADDING = 3;

    private double lastReach = -1.0;

    public final BooleanProperty renderBackground;
    public final IntProperty offsetX;
    public final IntProperty offsetY;
    public final FloatProperty scale;

    public ReachDisplay() {
        super("ReachDisplay", false);
        this.renderBackground = new BooleanProperty("render-background", true);
        this.offsetX = new IntProperty("offset-x", 4, 0, 2000);
        this.offsetY = new IntProperty("offset-y", 20, 0, 2000);
        this.scale = new FloatProperty("scale", 1.0F, 0.5F, 2.0F);
    }

    @Override
    public void onDisabled() {
        this.lastReach = -1.0;
    }

    @EventTarget
    public void onLoadWorld(LoadWorldEvent event) {
        this.lastReach = -1.0;
    }

    @EventTarget
    public void onAttack(AttackEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null) {
            return;
        }
        Entity target = event.getTarget();
        if (target == null) {
            return;
        }
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);

        // preferred: the exact point the crosshair hit on the target
        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop != null
                && mop.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY
                && mop.entityHit == target
                && mop.hitVec != null) {
            this.lastReach = eyes.distanceTo(mop.hitVec);
            return;
        }

        // fallback: closest point of the target's hitbox to your eyes
        AxisAlignedBB box = target.getEntityBoundingBox();
        double x = Math.max(box.minX, Math.min(eyes.xCoord, box.maxX));
        double y = Math.max(box.minY, Math.min(eyes.yCoord, box.maxY));
        double z = Math.max(box.minZ, Math.min(eyes.zCoord, box.maxZ));
        this.lastReach = eyes.distanceTo(new Vec3(x, y, z));
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null || mc.gameSettings.showDebugInfo) {
            return;
        }
        String value = this.lastReach < 0.0 ? "N/A" : String.format("%.2f blocks", this.lastReach);
        String text = "Reach: " + value;
        float width = mc.fontRendererObj.getStringWidth(text) + PADDING * 2.0F;
        float height = mc.fontRendererObj.FONT_HEIGHT + PADDING * 2.0F - 1.0F;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) this.offsetX.getValue(), (float) this.offsetY.getValue(), 0.0F);
        GlStateManager.scale(this.scale.getValue(), this.scale.getValue(), 1.0F);
        if (this.renderBackground.getValue()) {
            RenderUtil.enableRenderState();
            RenderUtil.drawRect(0.0F, 0.0F, width, height, BACKGROUND);
            RenderUtil.disableRenderState();
        }
        mc.fontRendererObj.drawString(text, PADDING, PADDING, TEXT_COLOR, true);
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }
}
