package myau.module.modules;

import myau.module.Module;
import myau.property.properties.ColorProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.PercentProperty;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.opengl.GL11;

/**
 * BlockOverlay - replaces the vanilla black block outline with a colored
 * overlay (inside) and outline. Called from MixinEntityRenderer in place of
 * RenderGlobal#drawSelectionBox.
 */
public class BlockOverlay extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public final ColorProperty overlayColor;
    public final PercentProperty overlayOpacity;
    public final ColorProperty outlineColor;
    public final FloatProperty outlineWidth;

    public BlockOverlay() {
        super("BlockOverlay", false);
        this.overlayColor = new ColorProperty("overlay-color", 0xFFFFFF);
        this.overlayOpacity = new PercentProperty("overlay-opacity", 25);
        this.outlineColor = new ColorProperty("outline-color", 0xFFFFFF);
        this.outlineWidth = new FloatProperty("outline-width", 2.0F, 1.0F, 6.0F);
    }

    public void render(MovingObjectPosition hit, EntityPlayer player, float partialTicks) {
        if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || mc.theWorld == null) {
            return;
        }
        BlockPos pos = hit.getBlockPos();
        Block block = mc.theWorld.getBlockState(pos).getBlock();
        if (block.getMaterial() == Material.air || !mc.theWorld.getWorldBorder().contains(pos)) {
            return;
        }
        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        double dx = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double) partialTicks;
        double dy = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double) partialTicks;
        double dz = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double) partialTicks;
        AxisAlignedBB bb = block.getSelectedBoundingBox(mc.theWorld, pos)
                .expand(0.002D, 0.002D, 0.002D)
                .offset(-dx, -dy, -dz);

        int fill = this.overlayColor.getValue() & 0xFFFFFF;
        int line = this.outlineColor.getValue() & 0xFFFFFF;
        int fillAlpha = Math.round(this.overlayOpacity.getValue() * 255.0F / 100.0F);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableTexture2D();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);

        if (fillAlpha > 0) {
            fillBox(bb, (fill >> 16) & 255, (fill >> 8) & 255, fill & 255, fillAlpha);
        }

        GL11.glLineWidth(this.outlineWidth.getValue());
        RenderGlobal.drawOutlinedBoundingBox(bb, (line >> 16) & 255, (line >> 8) & 255, line & 255, 255);
        GL11.glLineWidth(2.0F);

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
    }

    private static void fillBox(AxisAlignedBB b, int r, int g, int bl, int a) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        // bottom
        wr.pos(b.minX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        // top
        wr.pos(b.minX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        // north
        wr.pos(b.minX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        // south
        wr.pos(b.minX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        // west
        wr.pos(b.minX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.minX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        // east
        wr.pos(b.maxX, b.minY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.minZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.maxY, b.maxZ).color(r, g, bl, a).endVertex();
        wr.pos(b.maxX, b.minY, b.maxZ).color(r, g, bl, a).endVertex();
        tessellator.draw();
    }
}
