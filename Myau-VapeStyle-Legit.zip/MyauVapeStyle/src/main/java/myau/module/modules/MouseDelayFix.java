package myau.module.modules;

import myau.event.EventTarget;
import myau.events.LeftClickMouseEvent;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import net.minecraft.client.Minecraft;

/**
 * MouseDelayFix - on 1.8.x the entity under the crosshair is only picked once per game tick (20x/s),
 * so a click is registered against a stale rotation. Like 1.7.10, this re-picks the target with the
 * current camera rotation at the exact moment you click, making aim and hit registration accurate.
 */
public class MouseDelayFix extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public MouseDelayFix() {
        super("MouseDelayFix", false);
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (!this.isEnabled()
                || mc.thePlayer == null
                || mc.theWorld == null
                || mc.getRenderViewEntity() == null
                || mc.currentScreen != null) {
            return;
        }
        float partialTicks = ((IAccessorMinecraft) mc).getTimer().renderPartialTicks;
        mc.entityRenderer.getMouseOver(partialTicks);
    }
}
