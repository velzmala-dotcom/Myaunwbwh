package myau.module.modules;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import myau.Myau;
import myau.enums.BlinkModules;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.events.AttackEvent;
import myau.events.TickEvent;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.PercentProperty;
import myau.property.properties.TextProperty;
import myau.util.PacketUtil;
import myau.util.PlayerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.Vec3;

public class HitFlick extends Module {
   private static final Minecraft mc = Minecraft.func_71410_x();
   private static final Pattern ID_PATTERN = Pattern.compile("^(\\d+)(?::(\\d+))?$");
   private static final Pattern SLOT_PATTERN = Pattern.compile("^slot\\s*(\\d+)$");
   public final BooleanProperty players = new BooleanProperty("players", true);
   public final BooleanProperty mobs = new BooleanProperty("mobs", false);
   public final BooleanProperty animals = new BooleanProperty("animals", false);
   public final BooleanProperty ignoreInvisible = new BooleanProperty("ignore-invisible", false);
   public final BooleanProperty ignoreNaked = new BooleanProperty("ignore-naked", false);
   public final BooleanProperty ignoreBehindWalls = new BooleanProperty("ignore-behind-walls", false);
   public final IntProperty angle = new IntProperty("angle", 90, 0, 360);
   public final PercentProperty chance = new PercentProperty("chance", 100);
   public final IntProperty flickDelay = new IntProperty("flick-delay", 200, 0, 2000);
   public final IntProperty randomizeOffset = new IntProperty("randomize-offset", 0, 0, 90);
   public final BooleanProperty strafeInvert = new BooleanProperty("strafe-invert", false);
   public final BooleanProperty selectHits = new BooleanProperty("select-hits", false);
   public final BooleanProperty blink = new BooleanProperty("blink", true);
   public final BooleanProperty limitItems = new BooleanProperty("limit-items", false);
   public final TextProperty allowedItems = new TextProperty("allowed-items", "swords", () -> (Boolean)this.limitItems.getValue());
   private final Random rng = new Random();
   private boolean pending = false;
   private boolean ownsBlink = false;
   private float restoreYaw;
   private float restorePitch;
   private long lastFlick = 0L;

   public HitFlick() {
      super("HitFlick", false);
   }

   public String[] getSuffix() {
      return new String[]{String.valueOf(this.angle.getValue())};
   }

   public void onDisabled() {
      this.finishFlick();
   }

   private boolean validTarget(Entity var1) {
      EntityPlayerSP var2 = mc.field_71439_g;
      if (var2 != null && var1 != null && var1 != var2 && !var1.field_70128_L) {
         if (!(var1 instanceof EntityLivingBase)) {
            return false;
         } else {
            if (var1 instanceof EntityPlayer) {
               if (!(Boolean)this.players.getValue()) {
                  return false;
               }
            } else if (var1 instanceof IMob) {
               if (!(Boolean)this.mobs.getValue()) {
                  return false;
               }
            } else {
               if (!(var1 instanceof EntityAnimal)) {
                  return false;
               }

               if (!(Boolean)this.animals.getValue()) {
                  return false;
               }
            }

            if ((Boolean)this.ignoreInvisible.getValue() && var1.func_82150_aj()) {
               return false;
            } else if ((Boolean)this.ignoreNaked.getValue() && var1 instanceof EntityPlayer && isNaked((EntityPlayer)var1)) {
               return false;
            } else {
               return !(Boolean)this.ignoreBehindWalls.getValue() || this.canSee(var2, var1);
            }
         }
      } else {
         return false;
      }
   }

   private static boolean isNaked(EntityPlayer var0) {
      ItemStack[] var1 = var0.field_71071_by == null ? null : var0.field_71071_by.field_70460_b;
      if (var1 == null) {
         return true;
      } else {
         for(ItemStack var5 : var1) {
            if (var5 != null) {
               return false;
            }
         }

         return true;
      }
   }

   private boolean canSee(EntityPlayerSP var1, Entity var2) {
      if (mc.field_71441_e == null) {
         return true;
      } else {
         Vec3 var3 = var1.func_174824_e(1.0F);
         Vec3 var4 = new Vec3(var2.field_70165_t, var2.field_70163_u + (double)var2.func_70047_e(), var2.field_70161_v);
         return mc.field_71441_e.func_72933_a(var3, var4) == null;
      }
   }

   private boolean itemAllowed() {
      if (!(Boolean)this.limitItems.getValue()) {
         return true;
      } else {
         EntityPlayerSP var1 = mc.field_71439_g;
         if (var1 == null) {
            return false;
         } else {
            int var2 = var1.field_71071_by.field_70461_c;
            return matchesList((String)this.allowedItems.getValue(), var1.func_70694_bm(), var2);
         }
      }
   }

   private static boolean matchesList(String var0, ItemStack var1, int var2) {
      if (var0 == null) {
         return false;
      } else {
         String var3 = "";
         if (var1 != null && var1.func_82833_r() != null) {
            var3 = var1.func_82833_r().replaceAll("§.", "").toLowerCase().replaceAll("[^a-z0-9]+", " ").trim();
         }

         for(String var7 : var0.split(",")) {
            String var8 = var7.trim().toLowerCase();
            if (!var8.isEmpty()) {
               if (!var8.equals("hand") && !var8.equals("fist") && !var8.equals("fists") && !var8.equals("empty")) {
                  Matcher var9 = SLOT_PATTERN.matcher(var8);
                  if (var9.matches()) {
                     if (Integer.parseInt(var9.group(1)) == var2 + 1) {
                        return true;
                     }
                  } else if (var1 != null) {
                     Item var10 = var1.func_77973_b();
                     Matcher var11 = ID_PATTERN.matcher(var8);
                     if (var11.matches()) {
                        try {
                           int var15 = Integer.parseInt(var11.group(1));
                           if (Item.func_150891_b(var10) == var15 && (var11.group(2) == null || var1.func_77952_i() == Integer.parseInt(var11.group(2)))) {
                              return true;
                           }
                        } catch (Throwable var14) {
                        }
                     } else {
                        switch (var8) {
                           case "sword":
                           case "swords":
                              if (var10 instanceof ItemSword) {
                                 return true;
                              }
                              break;
                           case "shovel":
                           case "shovels":
                           case "spade":
                           case "spades":
                              if (var10 instanceof ItemSpade) {
                                 return true;
                              }
                              break;
                           case "axe":
                           case "axes":
                              if (var10 instanceof ItemAxe) {
                                 return true;
                              }
                              break;
                           case "pickaxe":
                           case "pickaxes":
                              if (var10 instanceof ItemPickaxe) {
                                 return true;
                              }
                              break;
                           case "block":
                           case "blocks":
                              if (var10 instanceof ItemBlock) {
                                 return true;
                              }
                              break;
                           case "food":
                              if (var10 instanceof ItemFood) {
                                 return true;
                              }
                              break;
                           default:
                              String var12 = var8.replaceAll("[^a-z0-9]+", " ").trim();
                              if (!var12.isEmpty() && var3.contains(var12)) {
                                 return true;
                              }
                        }
                     }
                  }
               } else if (var1 == null) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private float pickAngle() {
      float var1 = (float)(Integer)this.angle.getValue();
      int var2 = (Integer)this.randomizeOffset.getValue();
      if (var2 > 0) {
         var1 += (this.rng.nextFloat() - 0.5F) * (float)var2;
      }

      if ((Boolean)this.strafeInvert.getValue()) {
         double var3 = Math.sin(Math.toRadians((double)var1));
         if (PlayerUtil.isMovingRight() && var3 > (double)0.0F || PlayerUtil.isMovingLeft() && var3 < (double)0.0F) {
            var1 = -var1;
         }
      }

      return var1;
   }

   @EventTarget
   public void onAttack(AttackEvent var1) {
      if (this.isEnabled() && !var1.isCancelled() && !this.pending) {
         EntityPlayerSP var2 = mc.field_71439_g;
         if (var2 != null) {
            Entity var3 = var1.getTarget();
            if (this.validTarget(var3)) {
               if (this.itemAllowed()) {
                  long var4 = System.currentTimeMillis();
                  if (var4 - this.lastFlick >= (long)(Integer)this.flickDelay.getValue()) {
                     if (this.rng.nextInt(100) < (Integer)this.chance.getValue()) {
                        if (!(Boolean)this.selectHits.getValue() || var3.field_70172_ad <= 10) {
                           this.restoreYaw = var2.field_70177_z;
                           this.restorePitch = var2.field_70125_A;
                           float var6 = this.restoreYaw + this.pickAngle();
                           if ((Boolean)this.blink.getValue() && Myau.blinkManager.getBlinkingModule() == BlinkModules.NONE) {
                              this.ownsBlink = Myau.blinkManager.setBlinkState(true, BlinkModules.BLINK);
                           }

                           PacketUtil.sendPacket(new C03PacketPlayer.C05PacketPlayerLook(var6, this.restorePitch, var2.field_70122_E));
                           this.pending = true;
                           this.lastFlick = var4;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventTarget
   public void onTick(TickEvent var1) {
      if (var1.getType() == EventType.POST) {
         this.finishFlick();
      }
   }

   private void finishFlick() {
      if (this.pending || this.ownsBlink) {
         EntityPlayerSP var1 = mc.field_71439_g;
         if (this.pending && var1 != null) {
            PacketUtil.sendPacket(new C03PacketPlayer.C05PacketPlayerLook(this.restoreYaw, this.restorePitch, var1.field_70122_E));
         }

         this.pending = false;
         if (this.ownsBlink) {
            Myau.blinkManager.setBlinkState(false, BlinkModules.BLINK);
            this.ownsBlink = false;
         }

      }
   }
}
