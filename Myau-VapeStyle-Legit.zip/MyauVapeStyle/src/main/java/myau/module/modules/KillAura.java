package myau.module.modules;

import com.google.common.base.CaseFormat;
import myau.Myau;
import myau.event.EventManager;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.event.types.Priority;
import myau.events.*;
import myau.management.RotationState;
import myau.mixin.IAccessorPlayerControllerMP;
import myau.module.Module;
import myau.property.properties.*;
import myau.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C02PacketUseEntity.Action;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.WorldSettings.GameType;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * KillAura - Vape-style layout (Single / Switch / Multi, angle, max targets,
 * swing range + attack range, CPS range, simple autoblock).
 * Written from scratch against the OpenMyau API. Public API used by other
 * modules is kept: getTarget(), isAttackAllowed(), shouldAutoBlock(),
 * isBlocking(), isPlayerBlocking().
 */
public class KillAura extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private final TimerUtil timer = new TimerUtil();
    private final List<EntityLivingBase> candidates = new ArrayList<>();
    private AttackData target = null;
    private int switchTick = 0;
    private boolean hitRegistered = false;
    private boolean blockingState = false;
    private boolean isBlocking = false;
    private boolean fakeBlockState = false;
    private long attackDelayMS = 0L;
    private int blockTick = 0;

    public final ModeProperty mode;
    public final IntProperty maxTargets;
    public final ModeProperty sort;
    public final ModeProperty autoBlock;
    public final BooleanProperty autoBlockRequirePress;
    public final FloatProperty autoBlockRange;
    public final FloatProperty swingRange;
    public final FloatProperty attackRange;
    public final IntProperty fov;
    public final IntProperty minCPS;
    public final IntProperty maxCPS;
    public final IntProperty switchDelay;
    public final ModeProperty rotations;
    public final ModeProperty moveFix;
    public final PercentProperty smoothing;
    public final IntProperty angleStep;
    public final BooleanProperty throughWalls;
    public final BooleanProperty requirePress;
    public final BooleanProperty allowMining;
    public final BooleanProperty weaponsOnly;
    public final BooleanProperty allowTools;
    public final BooleanProperty inventoryCheck;
    public final BooleanProperty botCheck;
    public final BooleanProperty players;
    public final BooleanProperty bosses;
    public final BooleanProperty mobs;
    public final BooleanProperty animals;
    public final BooleanProperty golems;
    public final BooleanProperty silverfish;
    public final BooleanProperty teams;
    public final ModeProperty showTarget;

    public KillAura() {
        super("KillAura", false);
        this.mode = new ModeProperty("mode", 0, new String[]{"SINGLE", "SWITCH", "MULTI"});
        this.maxTargets = new IntProperty("max-targets", 3, 1, 8, () -> this.mode.getValue() == 2);
        this.sort = new ModeProperty("sort", 0, new String[]{"DISTANCE", "HEALTH", "HURT_TIME", "FOV"});
        this.autoBlock = new ModeProperty("auto-block", 1, new String[]{"NONE", "VANILLA", "SPOOF", "FAKE"});
        this.autoBlockRequirePress = new BooleanProperty("auto-block-require-press", false);
        this.autoBlockRange = new FloatProperty("auto-block-range", 6.0F, 3.0F, 8.0F);
        this.swingRange = new FloatProperty("swing-range", 3.5F, 3.0F, 6.0F);
        this.attackRange = new FloatProperty("attack-range", 3.0F, 3.0F, 6.0F);
        this.fov = new IntProperty("fov", 360, 30, 360);
        this.minCPS = new IntProperty("min-aps", 12, 1, 20);
        this.maxCPS = new IntProperty("max-aps", 14, 1, 20);
        this.switchDelay = new IntProperty("switch-delay", 150, 0, 1000);
        this.rotations = new ModeProperty("rotations", 2, new String[]{"NONE", "LEGIT", "SILENT", "LOCK_VIEW"});
        this.moveFix = new ModeProperty("move-fix", 1, new String[]{"NONE", "SILENT", "STRICT"});
        this.smoothing = new PercentProperty("smoothing", 0);
        this.angleStep = new IntProperty("angle-step", 90, 30, 180);
        this.throughWalls = new BooleanProperty("through-walls", true);
        this.requirePress = new BooleanProperty("require-press", false);
        this.allowMining = new BooleanProperty("allow-mining", true);
        this.weaponsOnly = new BooleanProperty("weapons-only", true);
        this.allowTools = new BooleanProperty("allow-tools", false, this.weaponsOnly::getValue);
        this.inventoryCheck = new BooleanProperty("inventory-check", true);
        this.botCheck = new BooleanProperty("bot-check", true);
        this.players = new BooleanProperty("players", true);
        this.bosses = new BooleanProperty("bosses", false);
        this.mobs = new BooleanProperty("mobs", false);
        this.animals = new BooleanProperty("animals", false);
        this.golems = new BooleanProperty("golems", false);
        this.silverfish = new BooleanProperty("silverfish", false);
        this.teams = new BooleanProperty("teams", true);
        this.showTarget = new ModeProperty("show-target", 0, new String[]{"NONE", "DEFAULT", "HUD"});
    }

    // ------------------------------------------------------------------ public API

    public EntityLivingBase getTarget() {
        return this.target != null ? this.target.getEntity() : null;
    }

    public boolean isAttackAllowed() {
        if (Myau.moduleManager.modules.get(Scaffold.class).isEnabled()) {
            return false;
        }
        if (!this.weaponsOnly.getValue()
                || ItemUtil.hasRawUnbreakingEnchant()
                || this.allowTools.getValue() && ItemUtil.isHoldingTool()) {
            return !this.requirePress.getValue() || KeyBindUtil.isKeyDown(mc.gameSettings.keyBindAttack.getKeyCode());
        }
        return false;
    }

    public boolean shouldAutoBlock() {
        if (this.isPlayerBlocking() && this.isBlocking) {
            return !mc.thePlayer.isInWater() && !mc.thePlayer.isInLava() && this.autoBlock.getValue() == 2;
        }
        return false;
    }

    public boolean isBlocking() {
        return this.fakeBlockState && ItemUtil.isHoldingSword();
    }

    public boolean isPlayerBlocking() {
        return (mc.thePlayer.isUsingItem() || this.blockingState) && ItemUtil.isHoldingSword();
    }

    // ------------------------------------------------------------------ helpers

    private long getAttackDelay() {
        return 1000L / RandomUtil.nextLong(this.minCPS.getValue(), this.maxCPS.getValue());
    }

    private boolean canAttack() {
        if (this.inventoryCheck.getValue() && mc.currentScreen instanceof GuiContainer) {
            return false;
        }
        if (this.weaponsOnly.getValue()
                && !ItemUtil.hasRawUnbreakingEnchant()
                && !(this.allowTools.getValue() && ItemUtil.isHoldingTool())) {
            return false;
        }
        if (((IAccessorPlayerControllerMP) mc.playerController).getIsHittingBlock()) {
            return false;
        }
        if ((ItemUtil.isEating() || ItemUtil.isUsingBow()) && PlayerUtil.isUsingItem()) {
            return false;
        }
        AutoHeal autoHeal = (AutoHeal) Myau.moduleManager.modules.get(AutoHeal.class);
        if (autoHeal.isEnabled() && autoHeal.isSwitching()) {
            return false;
        }
        BedNuker bedNuker = (BedNuker) Myau.moduleManager.modules.get(BedNuker.class);
        if (bedNuker.isEnabled() && bedNuker.isReady()) {
            return false;
        }
        if (Myau.moduleManager.modules.get(Scaffold.class).isEnabled()
                || Myau.moduleManager.modules.get(AutoBlockIn.class).isEnabled()) {
            return false;
        }
        if (this.requirePress.getValue()) {
            return PlayerUtil.isAttacking();
        }
        return !this.allowMining.getValue()
                || !mc.objectMouseOver.typeOfHit.equals(MovingObjectType.BLOCK)
                || !PlayerUtil.isAttacking();
    }

    private boolean canAutoBlock() {
        if (!ItemUtil.isHoldingSword()) {
            return false;
        }
        return !this.autoBlockRequirePress.getValue() || PlayerUtil.isUsingItem();
    }

    private boolean isValidTarget(EntityLivingBase e) {
        if (!mc.theWorld.loadedEntityList.contains(e)) return false;
        if (e == mc.thePlayer || e == mc.thePlayer.ridingEntity) return false;
        if (e == mc.getRenderViewEntity() || e == mc.getRenderViewEntity().ridingEntity) return false;
        if (e.deathTime > 0) return false;
        if (RotationUtil.angleToEntity(e) > this.fov.getValue().floatValue()) return false;
        if (!this.throughWalls.getValue() && RotationUtil.rayTrace(e) != null) return false;
        if (e instanceof EntityOtherPlayerMP) {
            if (!this.players.getValue()) return false;
            EntityPlayer p = (EntityPlayer) e;
            if (TeamUtil.isFriend(p)) return false;
            return (!this.teams.getValue() || !TeamUtil.isSameTeam(p))
                    && (!this.botCheck.getValue() || !TeamUtil.isBot(p));
        }
        if (e instanceof EntityDragon || e instanceof EntityWither) return this.bosses.getValue();
        if (e instanceof EntitySilverfish) {
            return this.silverfish.getValue() && (!this.teams.getValue() || !TeamUtil.hasTeamColor(e));
        }
        if (e instanceof EntityMob || e instanceof EntitySlime) return this.mobs.getValue();
        if (e instanceof EntityAnimal || e instanceof EntityBat || e instanceof EntitySquid || e instanceof EntityVillager) {
            return this.animals.getValue();
        }
        if (e instanceof EntityIronGolem) {
            return this.golems.getValue() && (!this.teams.getValue() || !TeamUtil.hasTeamColor(e));
        }
        return false;
    }

    private boolean isInBlockRange(EntityLivingBase e) {
        return RotationUtil.distanceToEntity(e) <= (double) this.autoBlockRange.getValue();
    }

    private boolean isInSwingRange(EntityLivingBase e) {
        return RotationUtil.distanceToEntity(e) <= (double) this.swingRange.getValue();
    }

    private boolean isInAttackRange(EntityLivingBase e) {
        return RotationUtil.distanceToEntity(e) <= (double) this.attackRange.getValue();
    }

    private boolean isBoxInSwingRange(AxisAlignedBB box) {
        return RotationUtil.distanceToBox(box) <= (double) this.swingRange.getValue();
    }

    private boolean isBoxInAttackRange(AxisAlignedBB box) {
        return RotationUtil.distanceToBox(box) <= (double) this.attackRange.getValue();
    }

    private boolean hasValidTarget() {
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (e instanceof EntityLivingBase
                    && this.isValidTarget((EntityLivingBase) e)
                    && this.isInBlockRange((EntityLivingBase) e)) {
                return true;
            }
        }
        return false;
    }

    private boolean isPlayerTarget(EntityLivingBase e) {
        return e instanceof EntityPlayer && TeamUtil.isTarget((EntityPlayer) e);
    }

    private int findEmptySlot(int currentSlot) {
        for (int i = 0; i < 9; i++) {
            if (i != currentSlot && mc.thePlayer.inventory.getStackInSlot(i) == null) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (i != currentSlot) {
                ItemStack s = mc.thePlayer.inventory.getStackInSlot(i);
                if (s != null && !s.hasDisplayName()) return i;
            }
        }
        return Math.floorMod(currentSlot - 1, 9);
    }

    private void startBlock(ItemStack stack) {
        PacketUtil.sendPacket(new C08PacketPlayerBlockPlacement(stack));
        mc.thePlayer.setItemInUse(stack, stack.getMaxItemUseDuration());
        this.blockingState = true;
    }

    private void stopBlock() {
        PacketUtil.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        mc.thePlayer.stopUsingItem();
        this.blockingState = false;
    }

    private void sendUseItem() {
        ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
        this.startBlock(mc.thePlayer.getHeldItem());
    }

    private void hit(EntityLivingBase entity) {
        EventManager.call(new AttackEvent(entity));
        ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
        PacketUtil.sendPacket(new C02PacketUseEntity(entity, Action.ATTACK));
        if (mc.playerController.getCurrentGameType() != GameType.SPECTATOR) {
            PlayerUtil.attackEntity(entity);
        }
    }

    /** Attacks the main target; in MULTI mode also hits extra targets in range. */
    private boolean performAttack(float yaw, float pitch) {
        if (Myau.playerStateManager.digging || Myau.playerStateManager.placing) return false;
        if (this.isPlayerBlocking() && this.autoBlock.getValue() != 1) return false;
        if (this.attackDelayMS > 0L) return false;
        this.attackDelayMS += this.getAttackDelay();
        mc.thePlayer.swingItem();
        if ((this.rotations.getValue() != 0 || !this.isBoxInAttackRange(this.target.getBox()))
                && RotationUtil.rayTrace(this.target.getBox(), yaw, pitch, this.attackRange.getValue()) == null) {
            return false;
        }
        this.hit(this.target.getEntity());
        if (this.mode.getValue() == 2) {
            int extra = this.maxTargets.getValue() - 1;
            for (EntityLivingBase e : this.candidates) {
                if (extra <= 0) break;
                if (e != this.target.getEntity() && this.isInAttackRange(e)) {
                    this.hit(e);
                    extra--;
                }
            }
        }
        this.hitRegistered = true;
        return true;
    }

    // ------------------------------------------------------------------ events

    @EventTarget(Priority.LOW)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) return;
        if (this.attackDelayMS > 0L) this.attackDelayMS -= 50L;

        boolean attack = this.target != null && this.canAttack();
        boolean block = attack && this.canAutoBlock();
        if (!block) {
            this.isBlocking = false;
            this.fakeBlockState = false;
            this.blockTick = 0;
        }

        boolean swap = false;
        if (block) {
            boolean idle = !Myau.playerStateManager.digging && !Myau.playerStateManager.placing;
            switch (this.autoBlock.getValue()) {
                case 0: // NONE: block only while the player holds right click
                    if (PlayerUtil.isUsingItem()) {
                        this.isBlocking = true;
                        if (!this.isPlayerBlocking() && idle) swap = true;
                    } else {
                        this.isBlocking = false;
                        if (this.isPlayerBlocking() && idle) this.stopBlock();
                    }
                    this.fakeBlockState = false;
                    break;
                case 1: // VANILLA: keep blocking whenever a target is near
                    if (this.hasValidTarget()) {
                        if (!this.isPlayerBlocking() && idle) swap = true;
                        this.isBlocking = true;
                    } else {
                        this.isBlocking = false;
                    }
                    this.fakeBlockState = false;
                    break;
                case 2: // SPOOF: slot swap packets between hits
                    if (this.hasValidTarget()) {
                        int item = ((IAccessorPlayerControllerMP) mc.playerController).getCurrentPlayerItem();
                        if (!idle
                                || mc.thePlayer.inventory.currentItem != item
                                || this.isPlayerBlocking() && this.blockTick != 0
                                || this.attackDelayMS > 0L && this.attackDelayMS <= 50L) {
                            this.blockTick = 0;
                        } else {
                            PacketUtil.sendPacket(new C09PacketHeldItemChange(this.findEmptySlot(item)));
                            PacketUtil.sendPacket(new C09PacketHeldItemChange(item));
                            swap = true;
                            this.blockTick = 1;
                        }
                        this.isBlocking = true;
                    } else {
                        this.isBlocking = false;
                    }
                    this.fakeBlockState = false;
                    break;
                case 3: // FAKE: block animation only
                    this.isBlocking = false;
                    this.fakeBlockState = this.hasValidTarget();
                    if (PlayerUtil.isUsingItem() && !this.isPlayerBlocking() && idle) swap = true;
                    break;
                default:
                    break;
            }
        }

        boolean attacked = false;
        if (this.target != null && this.isBoxInSwingRange(this.target.getBox())) {
            int rot = this.rotations.getValue();
            if (rot == 2 || rot == 3) {
                float[] r = RotationUtil.getRotationsToBox(
                        this.target.getBox(),
                        event.getYaw(),
                        event.getPitch(),
                        (float) this.angleStep.getValue() + RandomUtil.nextFloat(-5.0F, 5.0F),
                        (float) this.smoothing.getValue() / 100.0F
                );
                event.setRotation(r[0], r[1], 1);
                if (rot == 3) {
                    Myau.rotationManager.setRotation(r[0], r[1], 1, true);
                }
                if (this.moveFix.getValue() != 0 || rot == 3) {
                    event.setPervRotation(r[0], 1);
                }
            }
            if (attack) {
                attacked = this.performAttack(event.getNewYaw(), event.getNewPitch());
            }
        }
        if (swap) {
            this.sendUseItem();
        }
    }

    @EventTarget
    public void onTick(TickEvent event) {
        if (!this.isEnabled()) return;
        if (event.getType() == EventType.POST) {
            if (this.isPlayerBlocking() && !mc.thePlayer.isBlocking()) {
                mc.thePlayer.setItemInUse(mc.thePlayer.getHeldItem(), mc.thePlayer.getHeldItem().getMaxItemUseDuration());
            }
            return;
        }
        // PRE: (re)select targets
        boolean reselect = this.target == null
                || !this.isValidTarget(this.target.getEntity())
                || !this.isBoxInAttackRange(this.target.getBox())
                || !this.isBoxInSwingRange(this.target.getBox())
                || this.timer.hasTimeElapsed(this.switchDelay.getValue().longValue());
        if (reselect) {
            this.timer.reset();
            this.candidates.clear();
            for (Entity e : mc.theWorld.loadedEntityList) {
                if (e instanceof EntityLivingBase
                        && this.isValidTarget((EntityLivingBase) e)
                        && (this.isInBlockRange((EntityLivingBase) e)
                        || this.isInSwingRange((EntityLivingBase) e)
                        || this.isInAttackRange((EntityLivingBase) e))) {
                    this.candidates.add((EntityLivingBase) e);
                }
            }
            if (this.candidates.isEmpty()) {
                this.target = null;
            } else {
                boolean anySwing = false, anyAttack = false, anyPlayer = false;
                for (EntityLivingBase e : this.candidates) {
                    anySwing |= this.isInSwingRange(e);
                    anyAttack |= this.isInAttackRange(e);
                    anyPlayer |= this.isPlayerTarget(e);
                }
                if (anySwing) this.candidates.removeIf(e -> !this.isInSwingRange(e));
                if (anyAttack) this.candidates.removeIf(e -> !this.isInAttackRange(e));
                if (anyPlayer) this.candidates.removeIf(e -> !this.isPlayerTarget(e));
                final int sortMode = this.sort.getValue();
                this.candidates.sort((a, b) -> {
                    int c = 0;
                    switch (sortMode) {
                        case 1:
                            c = Float.compare(TeamUtil.getHealthScore(a), TeamUtil.getHealthScore(b));
                            break;
                        case 2:
                            c = Integer.compare(a.hurtResistantTime, b.hurtResistantTime);
                            break;
                        case 3:
                            c = Float.compare(RotationUtil.angleToEntity(a), RotationUtil.angleToEntity(b));
                            break;
                        default:
                            break;
                    }
                    return c != 0 ? c : Double.compare(RotationUtil.distanceToEntity(a), RotationUtil.distanceToEntity(b));
                });
                if (this.mode.getValue() == 1 && this.hitRegistered) {
                    this.hitRegistered = false;
                    this.switchTick++;
                }
                if (this.mode.getValue() != 1 || this.switchTick >= this.candidates.size()) {
                    this.switchTick = 0;
                }
                this.target = new AttackData(this.candidates.get(this.switchTick));
            }
        }
        if (this.target != null) {
            this.target = new AttackData(this.target.getEntity());
        }
    }

    @EventTarget(Priority.LOWEST)
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.isCancelled() || mc.thePlayer == null || mc.theWorld == null) return;
        if (event.getPacket() instanceof C07PacketPlayerDigging) {
            C07PacketPlayerDigging p = (C07PacketPlayerDigging) event.getPacket();
            if (p.getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                this.blockingState = false;
            }
        }
        if (event.getPacket() instanceof C09PacketHeldItemChange) {
            this.blockingState = false;
            if (this.isBlocking) mc.thePlayer.stopUsingItem();
        }
    }

    @EventTarget
    public void onMove(MoveInputEvent event) {
        if (!this.isEnabled()) return;
        if (this.moveFix.getValue() == 1
                && this.rotations.getValue() != 3
                && RotationState.isActived()
                && RotationState.getPriority() == 1.0F
                && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }
        if (this.shouldAutoBlock()) {
            mc.thePlayer.movementInput.jump = false;
        }
    }

    @EventTarget
    public void onRender(Render3DEvent event) {
        if (!this.isEnabled() || this.target == null) return;
        if (this.showTarget.getValue() != 0
                && TeamUtil.isEntityLoaded(this.target.getEntity())
                && this.isAttackAllowed()) {
            Color color = new Color(-1);
            if (this.showTarget.getValue() == 1) {
                color = this.target.getEntity().hurtTime > 0 ? new Color(16733525) : new Color(5635925);
            } else if (this.showTarget.getValue() == 2) {
                color = ((HUD) Myau.moduleManager.modules.get(HUD.class)).getColor(System.currentTimeMillis());
            }
            RenderUtil.enableRenderState();
            RenderUtil.drawEntityBox(this.target.getEntity(), color.getRed(), color.getGreen(), color.getBlue());
            RenderUtil.disableRenderState();
        }
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isBlocking || (this.isEnabled() && this.target != null && this.canAttack())) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isBlocking || (this.isEnabled() && this.target != null && this.canAttack())) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isBlocking || (this.isEnabled() && this.target != null && this.canAttack())) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onCancelUse(CancelUseEvent event) {
        if (this.isBlocking) event.setCancelled(true);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnabled() {
        this.target = null;
        this.candidates.clear();
        this.switchTick = 0;
        this.hitRegistered = false;
        this.attackDelayMS = 0L;
        this.blockTick = 0;
    }

    @Override
    public void onDisabled() {
        this.blockingState = false;
        this.isBlocking = false;
        this.fakeBlockState = false;
    }

    @Override
    public void verifyValue(String value) {
        if (this.swingRange.getName().equals(value)) {
            if (this.swingRange.getValue() < this.attackRange.getValue()) {
                this.attackRange.setValue(this.swingRange.getValue());
            }
        } else if (this.attackRange.getName().equals(value)) {
            if (this.swingRange.getValue() < this.attackRange.getValue()) {
                this.swingRange.setValue(this.attackRange.getValue());
            }
        } else if (this.minCPS.getName().equals(value)) {
            if (this.minCPS.getValue() > this.maxCPS.getValue()) {
                this.maxCPS.setValue(this.minCPS.getValue());
            }
        } else if (this.maxCPS.getName().equals(value)) {
            if (this.minCPS.getValue() > this.maxCPS.getValue()) {
                this.minCPS.setValue(this.maxCPS.getValue());
            }
        }
    }

    @Override
    public String[] getSuffix() {
        return new String[]{CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.mode.getModeString())};
    }

    public static class AttackData {
        private final EntityLivingBase entity;
        private final AxisAlignedBB box;
        private final double x;
        private final double y;
        private final double z;

        public AttackData(EntityLivingBase entityLivingBase) {
            this.entity = entityLivingBase;
            double border = entityLivingBase.getCollisionBorderSize();
            this.box = entityLivingBase.getEntityBoundingBox().expand(border, border, border);
            this.x = entityLivingBase.posX;
            this.y = entityLivingBase.posY;
            this.z = entityLivingBase.posZ;
        }

        public EntityLivingBase getEntity() {
            return this.entity;
        }

        public AxisAlignedBB getBox() {
            return this.box;
        }

        public double getX() {
            return this.x;
        }

        public double getY() {
            return this.y;
        }

        public double getZ() {
            return this.z;
        }
    }
}
