package myau.module.modules;

import myau.module.Module;
import myau.ui.VapeGui;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class GuiModule extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private VapeGui gui;

    public GuiModule() {
        super("ClickGui", false);
        setKey(Keyboard.KEY_RSHIFT);
    }

    @Override
    public void onEnabled() {
        setEnabled(false);
        if (gui == null) {
            gui = new VapeGui();
        }
        mc.displayGuiScreen(gui);
    }
}
