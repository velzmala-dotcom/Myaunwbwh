package myau.util;

import myau.events.StrafeEvent;

public final class MovementCorrector {
   private MovementCorrector() {
   }

   public static void apply(StrafeEvent var0, int var1, float var2, float var3) {
      if (var1 == 0) {
         float var4 = (float)Math.toRadians((double)wrap180(var2 - var3));
         float var5 = (float)Math.cos((double)var4);
         float var6 = (float)Math.sin((double)var4);
         float var7 = var0.getStrafe();
         float var8 = var0.getForward();
         var0.setStrafe(var7 * var5 - var8 * var6);
         var0.setForward(var7 * var6 + var8 * var5);
      }
   }

   private static float wrap180(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }
}
