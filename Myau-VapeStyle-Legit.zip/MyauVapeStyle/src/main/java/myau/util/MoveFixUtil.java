package myau.util;

import myau.management.RotationState;
import myau.module.Module;
import myau.property.properties.ModeProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public final class MoveFixUtil {
   private static int lastTick = Integer.MIN_VALUE;
   private static EntityPlayerSP lastPlayer;

   private MoveFixUtil() {
   }

   private static int mode(ModeProperty var0) {
      Object var1 = var0.getValue();
      return var1 instanceof Integer ? (Integer)var1 : 0;
   }

   public static float headingFromReal(float var0, ModeProperty var1, float var2) {
      return mode(var1) == 2 ? var0 : var2;
   }

   public static float headingFromAim(float var0, ModeProperty var1, float var2) {
      return mode(var1) == 2 ? var2 : var0;
   }

   public static void apply(ModeProperty var0, Module var1, int var2) {
      if (var1 != null && var1.isEnabled()) {
         int var3 = mode(var0);
         if (var3 != 2) {
            if (RotationState.isActived()) {
               if (RotationState.getPriority() == (float)var2) {
                  Minecraft var4 = Minecraft.func_71410_x();
                  EntityPlayerSP var5 = var4.field_71439_g;
                  if (var5 != null && var5.field_71158_b != null) {
                     if (var5 != lastPlayer || var5.field_70173_aa != lastTick) {
                        if (MoveUtil.getForwardValue() != 0 || MoveUtil.getLeftValue() != 0) {
                           lastPlayer = var5;
                           lastTick = var5.field_70173_aa;
                           MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
                           if (var3 == 1 && var5.field_71158_b.field_78900_b <= 0.0F) {
                              var5.func_70031_b(false);
                           }

                        }
                     }
                  }
               }
            }
         }
      }
   }
}
